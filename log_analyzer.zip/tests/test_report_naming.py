"""Single current report per scope, Windows-safe YYYYMMDD timestamped naming."""
from __future__ import annotations

import csv
from datetime import datetime, timedelta, timezone
import json
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
import sys
import unittest
from unittest.mock import patch
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import analyze
import process_scheduler as ps
from report_naming import report_name


class TimestampNameTests(unittest.TestCase):
    def test_correct_yyyymmdd_and_windows_safe_time(self):
        when = datetime(2026, 11, 2, 9, 5, 7, tzinfo=timezone.utc)
        self.assertEqual(
            report_name('U5', 'DataPlatform_20261007_Thursday', when, 'xlsx'),
            'U5_DataPlatform_20261007_Thursday_20261102_09-05-07.xlsx',
        )
        self.assertEqual(
            report_name('PROD', 'ldnroot_autosys', when, 'csv'),
            'PROD_ldnroot_autosys_20261102_09-05-07.csv',
        )
        self.assertEqual(
            report_name('U5', 'DataPlatform_20261007_Thursday', when, 'xlsx', kind='duplicates'),
            'U5_DataPlatform_20261007_Thursday_duplicates_20261102_09-05-07.xlsx',
        )

    def test_invalid_filenames_are_rejected(self):
        for source in ('a:b', '../escape', 'a\\b'):
            with self.subTest(source=source), self.assertRaises(ValueError):
                report_name('U5', source, datetime.now(), 'xlsx')
        with self.assertRaises(ValueError):
            report_name('U5', 'ldnroot_autosys', datetime.now(), 'pdf')


class PublicationNamingTests(unittest.TestCase):
    def setUp(self):
        temp = TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.now = datetime(2026, 10, 9, 13, 17, 45, tzinfo=timezone.utc)
        self.cob = '20261007'
        self.topology = 'DataPlatform_20261007_Thursday'
        self.output = self.root / 'output'

    def test_ldnroot_csv_and_excel_exports_remove_previous_visible_version(self):
        logs = self.root / 'source' / self.cob / 'Top'
        logs.mkdir(parents=True)
        log = logs / 'a.log'
        log.write_text('2026-10-07 00:00:01 [1] ERROR : fail\n  stack line\n', encoding='utf-8')

        def run(fmt: str, when: datetime):
            return analyze.write_csv(root=self.root / 'source', output_dir=self.output,
                environment='U5', encoding='utf-8-sig', only_date=self.cob,
                delimiter=',', output_format=fmt, now=when, mode='enrich',
                stdout=StringIO(), stderr=StringIO())

        self.assertEqual(run('csv', self.now)[0], 1)
        report_dir = self.output / 'U5' / self.cob
        initial = report_dir / report_name('U5', 'ldnroot_autosys', self.now, 'csv')
        self.assertTrue(initial.is_file())
        self.assertEqual(len(list(report_dir.iterdir())), 1)
        self.assertEqual(run('csv', self.now + timedelta(seconds=10))[0], 0)
        self.assertTrue(initial.is_file())  # no change -> no redundant timestamped export

        with patch.object(analyze, 'open_shared_log', side_effect=AssertionError('must reuse cache')):
            self.assertEqual(run('xlsx', self.now + timedelta(minutes=1))[0], 0)
        workbook = report_dir / report_name('U5', 'ldnroot_autosys',
                                          self.now + timedelta(minutes=1), 'xlsx')
        self.assertTrue(workbook.is_file())
        self.assertFalse(initial.exists())
        with ZipFile(workbook) as file:
            self.assertIn(b'autoFilter', file.read('xl/worksheets/sheet1.xml'))
        self.assertEqual(len(list(report_dir.iterdir())), 1)
        meta = json.loads((self.output / 'U5' / '.state' / 'published' / f'{self.cob}.json').read_text())
        self.assertEqual(meta['path'], str(workbook))

    def test_process_scheduler_republishes_after_time_changes_and_retains_diagnostics(self):
        share = self.root / 'share'
        folder = share / self.cob / self.topology
        folder.mkdir(parents=True)
        (folder / 'job.log').write_text('2026-10-07 00:00:00 [1] INFO : OK\n', encoding='utf-8')
        cfg = {'environments': {'U5': {'process_scheduler': {
            'share': 'RALogs', 'hosts': [{'name': 'host.example.net', 'root': str(share)}],
            'default_topology': 'DataPlatform',
        }}}}
        dest = self.output / 'U5' / 'process_scheduler' / 'DataPlatform' / self.cob / self.topology
        diag = self.output / 'logs' / 'U5' / self.cob / self.topology

        def run(when: datetime, host_failure: bool):
            hosts = cfg['environments']['U5']['process_scheduler']['hosts']
            if host_failure and len(hosts) == 1:
                hosts.append({'name': 'offline.example.net', 'root': str(self.root / 'offline')})
            return ps.extract(config=cfg, config_dir=self.root, environment='U5',
                topology=self.topology, output_dir=self.output, encoding='utf-8-sig',
                output_format='csv', now=when, stdout=StringIO(), stderr=StringIO())

        self.assertEqual(run(self.now, False), 0)
        prior = dest / report_name('U5', self.topology, self.now, 'csv')
        self.assertTrue(prior.exists())
        self.assertEqual(run(self.now + timedelta(minutes=1), True), 2)
        newer = dest / report_name('U5', self.topology, self.now + timedelta(minutes=1), 'csv')
        self.assertTrue(newer.exists())
        self.assertFalse(prior.exists())
        self.assertEqual(len(list(dest.glob('*.csv'))), 2)  # current jobs + duplicates only
        latest = json.loads((diag / 'latest.json').read_text())
        self.assertEqual(latest['report'], str(newer))
        self.assertEqual(latest['status'], 'CompletedWithWarnings')
        self.assertTrue((diag / '_last_complete' / 'jobs.csv').exists())
        self.assertEqual(len(list(diag.glob('*/run.json'))), 2)
        self.assertTrue(all('issues.log' in [f.name for f in run_dir.iterdir()]
                            for run_dir in diag.iterdir() if run_dir.is_dir() and run_dir.name[0].isdigit()))


if __name__ == '__main__':
    unittest.main()
