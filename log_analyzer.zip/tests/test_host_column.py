"""Host column source attribution, caching, and on-disk schema migration."""
from __future__ import annotations

import csv
import json
import os
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import analyze
import process_scheduler


class RootHostTests(unittest.TestCase):
    def test_unc_root_extraction(self):
        self.assertEqual(analyze.host_from_root(r'\\ldnroot\data\IBCT\CVA\Logs'), 'ldnroot')
        self.assertEqual(analyze.host_from_root(r'\\LDNROOT\DATA\Logs'), 'ldnroot')
        self.assertEqual(analyze.host_from_root(r'\\ra-u5-as-08.ubs.net\RALogs'), 'ra-u5-as-08.ubs.net')
        self.assertEqual(analyze.host_from_root('/srv/logs'), '')
        self.assertEqual(analyze.host_from_root('Z:\\Logs'), '')
        self.assertEqual(analyze.CSV_FIELDS[-3:], ('activity_status', 'host', 'path'))


class ExistingReportTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.base = Path(temp.name)
        self.root = self.base / 'logs'
        self.log = self.root / '20261007' / 'jobs' / 'hello.log'
        self.log.parent.mkdir(parents=True)
        self.log.write_text('2026-10-08 09:00:00 [1] ERROR : broken\n', encoding='utf-8')
        self.output = self.base / 'reports'
        self.report = self.output / 'U5' / '.state' / 'report_csv' / '20261007.csv'
        self.state = self.output / 'U5' / '.state' / '20261007.json'
        self.now = datetime(2026, 10, 9, 9, tzinfo=timezone.utc)

    def run_mode(self, mode='inventory', *, now=None, policy=None):
        return analyze.write_csv(
            root=self.root, output_dir=self.output, environment='U5', encoding='utf-8-sig',
            only_date='20261007', delimiter=',', mode=mode,
            policy=policy or analyze.IncrementalPolicy(),
            now=now or self.now, stdout=StringIO(), stderr=StringIO(),
        )

    def read_rows(self):
        with self.report.open(encoding='utf-8-sig', newline='') as handle:
            return list(csv.DictReader(handle))

    def drop_host_from_csv_and_state(self):
        rows = self.read_rows()
        older = [name for name in analyze.CSV_FIELDS if name != 'host']
        with self.report.open('w', encoding='utf-8-sig', newline='') as output:
            writer = csv.DictWriter(output, fieldnames=older)
            writer.writeheader()
            for row in rows:
                row.pop('host')
                writer.writerow(row)
        state = json.loads(self.state.read_text())
        if state['status'] == 'open':
            for entry in state['files'].values():
                entry['row'].pop('host', None)
        self.state.write_text(json.dumps(state), encoding='utf-8')

    def test_inventory_migrates_old_cached_rows_without_parsing(self):
        with patch.object(analyze, 'host_from_root', return_value='ldnroot'):
            self.run_mode('inventory')
            self.drop_host_from_csv_and_state()
            with patch.object(analyze, 'open_shared_log', side_effect=AssertionError('no content read')):
                self.run_mode('inventory')
        rows = self.read_rows()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['host'], 'ldnroot')
        self.assertEqual(rows[0]['path'], 'jobs/hello.log')
        self.assertEqual(json.loads(self.state.read_text())['files']['jobs/hello.log']['row']['host'], 'ldnroot')

    def test_enrich_cached_rows_get_host_without_reparse(self):
        with patch.object(analyze, 'host_from_root', return_value='ldnroot'):
            self.run_mode('enrich')
            self.drop_host_from_csv_and_state()
            with patch.object(analyze, 'stable_summary', side_effect=AssertionError('should be cached')):
                self.run_mode('enrich')
        row = self.read_rows()[0]
        self.assertEqual(row['host'], 'ldnroot')
        self.assertEqual(row['enrichment_status'], 'Enriched')
        self.assertEqual(row['error_count'], '1')

    def test_closed_cob_migrates_header_without_revisiting_logs(self):
        older = datetime(2026, 9, 1, tzinfo=timezone.utc).timestamp()
        os.utime(self.log, (older, older))
        frozen = datetime(2026, 10, 19, 9, tzinfo=timezone.utc)
        with patch.object(analyze, 'host_from_root', return_value='ldnroot'):
            self.run_mode('enrich', now=frozen)
            self.assertEqual(json.loads(self.state.read_text())['status'], 'closed')
            self.drop_host_from_csv_and_state()
            with patch.object(analyze, 'iter_log_files', side_effect=AssertionError('closed sources must not be scanned')):
                self.run_mode('enrich', now=frozen)
        row = self.read_rows()[0]
        self.assertEqual(row['host'], 'ldnroot')
        self.assertEqual(row['last_error'], '2026-10-08 09:00:00 [1] ERROR : broken')


class ProcessSchedulerHostTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.base = Path(temp.name)
        self.h0 = self.base / 'shareA'
        self.h1 = self.base / 'shareB'
        self.folder = 'DataPlatform_20261007_Thursday'
        self.roots = [self.h0, self.h1]
        self.names = ['ra-u5-as-08.ubs.net', 'ra-u5-as-05.ubs.net']
        self.settings = {'environments': {'U5': {
            'logs_root': str(self.base / 'other'),
            'process_scheduler': {
                'share': 'RALogs', 'default_topology': 'DataPlatform',
                'hosts': [{'name': name, 'root': str(root)} for name, root in zip(self.names, self.roots)],
                'host_aliases': {},
            }
        }}}
        self.output = self.base / 'output'

    def log(self, index, data, filename='job.log'):
        path = self.roots[index] / '20261007' / self.folder / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(data, encoding='utf-8')
        return path

    def run_extract(self):
        return process_scheduler.extract(
            config=self.settings, config_dir=self.base, environment='U5',
            topology=self.folder, output_dir=self.output, encoding='utf-8-sig',
            now=datetime(2026, 10, 8, 12, tzinfo=timezone.utc),
            stdout=StringIO(), stderr=StringIO(),
        )

    def rows(self):
        report = self.output / 'U5' / 'process_scheduler' / 'DataPlatform' / '20261007' / self.folder / process_scheduler.report_filename('U5', '20261007', self.folder, 'jobs', 'csv', created_at=datetime(2026, 10, 8, 12, tzinfo=timezone.utc))
        with report.open(encoding='utf-8-sig', newline='') as source:
            return list(csv.DictReader(source))

    def test_original_host_is_kept_for_duplicate(self):
        content = '2026-10-07 10:00:00 [1] INFO : Same\n'
        self.log(0, content)
        self.log(1, content)
        self.assertEqual(self.run_extract(), 0)
        rows = self.rows()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['host'], self.names[0])
        self.assertIn('shareA', rows[0]['path'])

    def test_different_content_keeps_both_hosts(self):
        self.log(0, '2026-10-07 10:00:00 [1] ERROR : First\n')
        self.log(1, '2026-10-07 10:00:00 [1] ERROR : Second\n')
        self.assertEqual(self.run_extract(), 0)
        rows = self.rows()
        self.assertEqual(len(rows), 2)
        self.assertEqual({row['host'] for row in rows}, set(self.names))
        self.assertEqual({row['last_error'].split(': ')[-1] for row in rows}, {'First', 'Second'})

    def test_no_timestamp_still_has_hostname(self):
        self.log(0, 'unstructured log with no dates\n')
        self.h1.mkdir(exist_ok=True)
        self.assertEqual(self.run_extract(), 0)
        row = self.rows()[0]
        self.assertEqual(row['enrichment_status'], 'NoTimestamps')
        self.assertEqual(row['host'], self.names[0])

    def test_partial_report_still_includes_host(self):
        self.log(0, 'unstructured log with no dates\n')
        # The other enabled server does not exist, so output must be partial.
        self.assertEqual(self.run_extract(), 2)
        report = (self.output / 'U5' / 'process_scheduler' / 'DataPlatform' /
                  '20261007' / self.folder / process_scheduler.report_filename('U5', '20261007', self.folder, 'jobs', 'csv', created_at=datetime(2026, 10, 8, 12, tzinfo=timezone.utc)))
        with report.open(encoding='utf-8-sig', newline='') as source:
            row = next(csv.DictReader(source))
        self.assertEqual(row['enrichment_status'], 'NoTimestamps')
        self.assertEqual(row['host'], self.names[0])
        self.assertFalse(report.with_name('jobs.partial.csv').exists())


if __name__ == '__main__':
    unittest.main()
