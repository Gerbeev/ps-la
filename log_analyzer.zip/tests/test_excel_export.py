"""XLSX layout, safe publication, export selection and incremental compatibility."""
from __future__ import annotations

import csv
from datetime import datetime, timezone
from io import StringIO
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import analyze
import excel_export
import menu
import process_scheduler

NS = {'x': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}


class XlsxFormatTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_workbook_filters_header_fixed_heights_multiline_and_formula_literal(self):
        source = self.root / 'jobs.partial.csv'
        with source.open('w', encoding='utf-8-sig', newline='') as stream:
            writer = csv.writer(stream)
            writer.writerow(['job_name', 'last_error', 'host', 'path'])
            writer.writerow(['=HYPERLINK("http://evil")', 'first\nsecond\nthird\nfourth\nfifth',
                             'agent.example.org', r'\\host\RALogs\job.log'])
        target = self.root / 'jobs.partial.xlsx'
        excel_export.export_csv_to_xlsx(source, target)
        self.assertTrue(target.is_file())
        with ZipFile(target) as workbook:
            sheet_xml = workbook.read('xl/worksheets/sheet1.xml')
            sheet = ET.fromstring(sheet_xml)
            styles = ET.fromstring(workbook.read('xl/styles.xml'))
            self.assertIsNotNone(sheet.find('.//x:autoFilter', NS))
            self.assertEqual(sheet.find('.//x:autoFilter', NS).attrib['ref'], 'A1:D2')
            self.assertEqual(sheet.find('.//x:pane', NS).attrib['state'], 'frozen')
            rows = sheet.findall('.//x:sheetData/x:row', NS)
            self.assertEqual([row.attrib['ht'] for row in rows], ['26', '19'])
            self.assertTrue(all(row.attrib['customHeight'] == '1' for row in rows))
            self.assertEqual(rows[0].find('./x:c', NS).attrib['s'], '1')
            self.assertIn('first\nsecond\nthird\nfourth\nfifth', sheet_xml.decode('utf-8'))
            self.assertIn('=HYPERLINK', sheet_xml.decode('utf-8'))
            self.assertNotIn(b'<f>', sheet_xml)
            self.assertIsNotNone(styles.find('.//x:font/x:b', NS))
            self.assertEqual(sheet.find('.//x:cols/x:col', NS).attrib['width'], '53')
            self.assertTrue(source.exists())

    def test_excel_export_accepts_windows_32_bit_c_long_limit(self):
        """Windows uses 32-bit C long even when Python's sys.maxsize is 64-bit."""
        source = self.root / 'jobs.csv'
        message = 'x' * 150_000  # Larger than csv's default 128-KiB limit.
        with source.open('w', encoding='utf-8', newline='') as stream:
            writer = csv.writer(stream)
            writer.writerow(['job_name', 'last_error'])
            writer.writerow(['job', message])

        real_set_limit = csv.field_size_limit
        attempted = []

        def windows_set_limit(limit):
            attempted.append(limit)
            if limit > 2_147_483_647:
                raise OverflowError('Python int too large to convert to C long')
            return real_set_limit(limit)

        destination = self.root / 'jobs.xlsx'
        original_limit = real_set_limit()
        try:
            with patch.object(excel_export.csv, 'field_size_limit', side_effect=windows_set_limit):
                excel_export.export_csv_to_xlsx(source, destination)
        finally:
            real_set_limit(original_limit)

        self.assertTrue(destination.is_file())
        self.assertGreater(attempted[-1], 150_000)
        self.assertLessEqual(attempted[-1], 2_147_483_647)
        with ZipFile(destination) as workbook:
            xml = workbook.read('xl/worksheets/sheet1.xml')
            self.assertEqual(len(ET.fromstring(xml).findall('.//x:sheetData/x:row', NS)), 2)
            self.assertIn('x' * 100, xml.decode('utf-8'))

    def test_atomic_export_keeps_prior_workbook_on_invalid_source(self):
        target = self.root / 'jobs.xlsx'
        target.write_bytes(b'untouched')
        csv_path = self.root / 'jobs.csv'
        csv_path.write_text('h1,h2\na\n', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'cells'):
            excel_export.export_csv_to_xlsx(csv_path, target)
        self.assertEqual(target.read_bytes(), b'untouched')
        self.assertFalse(list(self.root.glob('.xlsx-*')))

    def test_config_invalid_selection_rejected(self):
        data = {'environments': {'U5': {'logs_root': '/tmp/logs'}}, 'output_format': 'pdf'}
        with self.assertRaisesRegex(ValueError, 'output_format'):
            analyze.validate_config(data)

    def test_menu_settings_switch(self):
        config_path = self.root / 'config.json'
        config_path.write_text(json.dumps({'environments': {'U5': {'logs_root': '/tmp/logs'}}}), encoding='utf-8')
        choices = iter(['9', '10', '2', '0', '0'])
        out = StringIO()
        app = menu.ConsoleMenu(read=lambda _: next(choices), output=out, config_path=config_path)
        self.assertEqual(app.run(), 0)
        self.assertIn('Excel (.xlsx)', out.getvalue())
        self.assertEqual(menu.read_config(config_path)['output_format'], 'xlsx')

    def test_incremental_switch_without_reopening_log(self):
        folder = self.root / 'Logs' / '20261007' / 'System'
        folder.mkdir(parents=True)
        log = folder / 'job.log'
        log.write_text('2026-10-07 12:00:00,123 [1] ERROR: first\n  detail 1\n'
                       '  detail 2\n', encoding='utf-8')
        output = self.root / 'output'
        timestamp = datetime(2026, 10, 8, tzinfo=timezone.utc)

        def invoke(fmt, mode='enrich'):
            return analyze.write_csv(root=self.root / 'Logs', output_dir=output,
                environment='U5', encoding='utf-8-sig', only_date='20261007',
                delimiter=',', now=timestamp, output_format=fmt, mode=mode,
                stdout=StringIO(), stderr=StringIO())

        def visible(fmt):
            return target / f'U5_ldnroot_autosys_20261008_00-00-00.{fmt}'

        result = invoke('xlsx')
        target = output / 'U5' / '20261007'
        self.assertTrue(visible('xlsx').is_file())
        self.assertFalse(visible('csv').exists())
        cache = output / 'U5' / '.state' / 'report_csv' / '20261007.csv'
        self.assertTrue(cache.is_file())
        with patch.object(analyze, 'open_shared_log', side_effect=AssertionError('must reuse parsed log')):
            invoke('xlsx')
            invoke('csv')
        self.assertTrue(visible('csv').is_file())
        self.assertFalse(visible('xlsx').exists())
        with patch.object(analyze, 'open_shared_log', side_effect=AssertionError('must reuse parsed log')):
            invoke('xlsx')
        self.assertTrue(visible('xlsx').is_file())
        self.assertFalse(visible('csv').exists())

    def test_previous_csv_changes_take_priority_over_old_excel_cache(self):
        env_dir = self.root / 'U5'
        target = env_dir / '20261007' / 'jobs.csv'
        target.parent.mkdir(parents=True)
        cached = env_dir / '.state' / 'report_csv'  / '20261007.csv'
        cached.parent.mkdir(parents=True)
        cached.write_text('name\nold\n', encoding='utf-8')
        target.write_text('name\nnew\n', encoding='utf-8')
        selected = excel_export.ordinary_csv_storage(env_dir, '20261007', 'xlsx')
        self.assertEqual(selected.read_text(encoding='utf-8'), 'name\nnew\n')

    def test_process_scheduler_complete_xlsx_and_cleanup_partial(self):
        active = self.root / 'host_active'
        cob = '20261007'
        topo = 'DataPlatform_20261007_Thursday'
        log = active / cob / topo / 'job.log'
        log.parent.mkdir(parents=True)
        log.write_text('2026-10-07 11:01:01,123 [1] ERROR: fail\n'
                       '  detail1\n  detail2\n', encoding='utf-8')
        config = {'output_format': 'xlsx', 'environments': {'U5': {
            'logs_root': 'unused', 'process_scheduler': {
                'share': 'RALogs', 'default_topology': 'DataPlatform',
                'topology_base_url': 'https://example.org/Topology/Index/',
                'hosts': [{'name': 'agent.example.org', 'root': str(active)}],
                'host_aliases': {},
            }}}}
        output_dir = self.root / 'output'
        folder = output_dir / 'U5' / 'process_scheduler' / 'DataPlatform' / cob / topo
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'jobs.partial.xlsx').write_bytes(b'prior incomplete')
        (folder / 'duplicates.partial.xlsx').write_bytes(b'prior incomplete')
        (folder / 'issues.partial.txt').write_text('prior', encoding='utf-8')
        # Simulate the 32-bit C long accepted by Windows's CSV extension in
        # the complete Process Scheduler extraction -> XLSX publication flow.
        real_set_limit = csv.field_size_limit

        def windows_set_limit(limit):
            if limit > 2_147_483_647:
                raise OverflowError('Python int too large to convert to C long')
            return real_set_limit(limit)

        original_limit = real_set_limit()
        try:
            with patch.object(excel_export.csv, 'field_size_limit', side_effect=windows_set_limit):
                code = process_scheduler.extract(config=config, config_dir=self.root,
                    environment='U5', topology=topo, output_dir=output_dir,
                    encoding='utf-8-sig', now=datetime(2026, 10, 8, tzinfo=timezone.utc),
                    output_format='xlsx', stdout=StringIO(), stderr=StringIO())
        finally:
            real_set_limit(original_limit)
        self.assertEqual(code, 0)
        self.assertTrue((folder / process_scheduler.report_filename('U5', cob, topo, 'jobs', 'xlsx', created_at=datetime(2026, 10, 8, tzinfo=timezone.utc))).exists())
        self.assertTrue((folder / process_scheduler.report_filename('U5', cob, topo, 'duplicates', 'xlsx', created_at=datetime(2026, 10, 8, tzinfo=timezone.utc))).exists())
        self.assertFalse((folder / 'jobs.csv').exists())
        self.assertFalse((folder / 'duplicates.csv').exists())
        self.assertFalse((folder / 'jobs.partial.xlsx').exists())
        self.assertFalse((folder / 'duplicates.partial.xlsx').exists())
        self.assertFalse((folder / 'issues.partial.txt').exists())

    def test_process_scheduler_partial_xlsx_and_complete_report_preserved(self):
        active = self.root / 'host_active'
        inactive = self.root / 'host_inaccessible'
        cob = '20261007'
        topo = 'DataPlatform_20261007_Thursday'
        log = active / cob / topo / 'job.log'
        log.parent.mkdir(parents=True)
        log.write_text('no timestamp in this log', encoding='utf-8')
        config = {'output_format': 'xlsx', 'environments': {'U5': {
            'logs_root': 'unused', 'process_scheduler': {
                'share': 'RALogs', 'default_topology': 'DataPlatform',
                'topology_base_url': 'https://example.org/Topology/Index/',
                'hosts': [{'name': 'active.example.org', 'root': str(active)},
                          {'name': 'inactive.example.org', 'root': str(inactive)}],
                'host_aliases': {},
            }}}}
        output_dir = self.root / 'output'
        report_dir = output_dir / 'U5' / 'process_scheduler' / 'DataPlatform' / cob / topo
        report_dir.mkdir(parents=True, exist_ok=True)
        (report_dir / 'jobs.csv').write_text('previous complete', encoding='utf-8')
        result = process_scheduler.extract(config=config, config_dir=self.root, environment='U5',
            topology=topo, output_dir=output_dir, encoding='utf-8-sig',
            now=datetime(2026, 10, 8, tzinfo=timezone.utc), output_format='xlsx',
            stdout=StringIO(), stderr=StringIO())
        self.assertEqual(result, 2)
        self.assertTrue((report_dir / process_scheduler.report_filename('U5', cob, topo, 'jobs', 'xlsx', created_at=datetime(2026, 10, 8, tzinfo=timezone.utc))).exists())
        self.assertTrue((report_dir / process_scheduler.report_filename('U5', cob, topo, 'duplicates', 'xlsx', created_at=datetime(2026, 10, 8, tzinfo=timezone.utc))).exists())
        diag = list((output_dir / 'logs' / 'U5' / cob / topo).glob('*/run.json'))
        self.assertEqual(len(diag), 1)
        self.assertEqual(json.loads(diag[0].read_text())['status'], 'CompletedWithWarnings')
        self.assertFalse((report_dir / 'jobs.partial.csv').exists())
        self.assertEqual((output_dir / 'logs' / 'U5' / cob / topo / '_last_complete' / 'jobs.csv').read_text(encoding='utf-8'), 'previous complete')
        with ZipFile(report_dir / process_scheduler.report_filename('U5', cob, topo, 'jobs', 'xlsx', created_at=datetime(2026, 10, 8, tzinfo=timezone.utc))) as workbook:
            self.assertIn(b'NoTimestamps', workbook.read('xl/worksheets/sheet1.xml'))


if __name__ == '__main__':
    unittest.main()
