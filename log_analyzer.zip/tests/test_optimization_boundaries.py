"""Regression tests for bounded export and shared atomic file copies."""
from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import MagicMock, patch
import xml.etree.ElementTree as ET
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import atomic_io
import excel_export
import process_scheduler as ps

NS = {'x': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}


class AtomicBinaryCopyTests(unittest.TestCase):
    def setUp(self) -> None:
        tmp = TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.source = self.root / 'source.bin'
        self.source.write_bytes(b'new content\x00\xff')
        self.target = self.root / 'nested' / 'report.bin'
        self.target.parent.mkdir()
        self.target.write_bytes(b'old content')

    def assert_no_temp_files(self) -> None:
        self.assertEqual(list(self.target.parent.glob('*.tmp')), [])

    def test_successfully_replaces_complete_bytes(self) -> None:
        atomic_io.atomic_binary_copy(self.source, self.target, prefix='.copy-')
        self.assertEqual(self.target.read_bytes(), self.source.read_bytes())
        self.assert_no_temp_files()

    def test_partial_copy_failure_keeps_previous_report(self) -> None:
        def broken_copy(source, destination):
            destination.write(b'incomplete')
            raise OSError('interrupted copy')

        with patch.object(atomic_io.shutil, 'copyfileobj', side_effect=broken_copy):
            with self.assertRaisesRegex(OSError, 'interrupted copy'):
                atomic_io.atomic_binary_copy(self.source, self.target, prefix='.copy-')
        self.assertEqual(self.target.read_bytes(), b'old content')
        self.assert_no_temp_files()

    def test_replace_failure_keeps_previous_report(self) -> None:
        with patch.object(atomic_io.os, 'replace', side_effect=OSError('access denied')):
            with self.assertRaisesRegex(OSError, 'access denied'):
                atomic_io.atomic_binary_copy(self.source, self.target, prefix='.copy-')
        self.assertEqual(self.target.read_bytes(), b'old content')
        self.assert_no_temp_files()


class StreamingExportTests(unittest.TestCase):
    def test_cell_addresses_values_and_filter_after_row_batching(self) -> None:
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'logs.csv'
            destination = root / 'report.xlsx'
            with source.open('w', newline='', encoding='utf-8-sig') as stream:
                writer = csv.writer(stream)
                writer.writerows((('job_name', 'last_error', 'host'),
                                  ('job-a', 'ERROR: a < b & c\nstack frame', 'agent-a'),
                                  ('job-b', 'ERROR: second', 'agent-b')))
            excel_export.export_csv_to_xlsx(source, destination)
            with ZipFile(destination) as workbook:
                xml = ET.fromstring(workbook.read('xl/worksheets/sheet1.xml'))
            rows = xml.findall('.//x:sheetData/x:row', NS)
            self.assertEqual(len(rows), 3)
            self.assertEqual([row.attrib['ht'] for row in rows], ['26', '19', '19'])
            self.assertEqual(xml.find('.//x:autoFilter', NS).attrib['ref'], 'A1:C3')
            self.assertEqual(
                [[(cell.attrib['r'], cell.find('./x:is/x:t', NS).text)
                  for cell in row.findall('./x:c', NS)] for row in rows],
                [[('A1', 'job_name'), ('B1', 'last_error'), ('C1', 'host')],
                 [('A2', 'job-a'), ('B2', 'ERROR: a < b & c\nstack frame'), ('C2', 'agent-a')],
                 [('A3', 'job-b'), ('B3', 'ERROR: second'), ('C3', 'agent-b')]],
            )

    def test_group_iteration_remains_sorted_and_deduplicated(self) -> None:
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            cob = '20261007'
            topo = 'DataPlatform_20261007_Thursday'
            first = root / 'host1' / 'a.log'
            duplicate = root / 'host2' / 'a.log'
            last = root / 'host2' / 'z.log'
            for path, payload in ((first, '2026-10-07 10:00:00 INFO : started\n'),
                                  (duplicate, '2026-10-07 10:00:00 INFO : started\n'),
                                  (last, 'no timestamps\n')):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(payload, encoding='utf-8')

            def source(path: Path) -> ps.SourceLog:
                return ps.SourceLog(cob, topo, path.name, path.parent.name, path, path.stat())

            progress = MagicMock()
            extraction = ps._enrich_cob_logs(
                {(topo.lower(), 'z.log'): [source(last)],
                 (topo.lower(), 'a.log'): [source(first), source(duplicate)]},
                encoding='utf-8', now=datetime(2026, 10, 8, tzinfo=timezone.utc),
                recent_minutes=5, workers=2, progress=progress,
            )
            self.assertEqual(len(extraction.rows), 2)
            self.assertEqual(len(extraction.duplicates), 1)
            self.assertEqual(extraction.missing_timestamps, 1)
            queued = [call.args[0] for call in progress.file_queued.call_args_list]
            self.assertEqual(queued, [f'{topo}/a.log', f'{topo}/z.log'])
            progress.set_file_total.assert_called_once_with(2)


if __name__ == '__main__':
    unittest.main()