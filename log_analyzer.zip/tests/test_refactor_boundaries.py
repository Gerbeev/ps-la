"""Regression checks for persistence and refactored pipeline boundaries."""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import analyze
import atomic_io
import process_scheduler as ps


class AtomicWriterTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.target = self.directory / "reports" / "state.json"
        self.target.parent.mkdir()
        self.target.write_text('old', encoding='utf-8')

    def test_replacement_preserves_existing_file_on_serializer_error(self) -> None:
        with self.assertRaisesRegex(ValueError, 'serialization'):
            with atomic_io.atomic_text_writer(
                self.target, encoding='utf-8', newline='\n', prefix='.state-',
            ) as stream:
                stream.write('partial payload')
                raise ValueError('serialization failed')
        self.assertEqual(self.target.read_text(encoding='utf-8'), 'old')
        self.assertEqual(list(self.target.parent.glob('*.tmp')), [])

    def test_replacement_preserves_existing_file_on_publish_error(self) -> None:
        with patch.object(atomic_io.os, 'replace', side_effect=OSError('disk full')):
            with self.assertRaisesRegex(OSError, 'disk full'):
                with atomic_io.atomic_text_writer(
                    self.target, encoding='utf-8', newline='\n', prefix='.state-',
                ) as stream:
                    stream.write('new')
        self.assertEqual(self.target.read_text(encoding='utf-8'), 'old')
        self.assertEqual(list(self.target.parent.glob('*.tmp')), [])

    def test_atomic_json_replaces_old_state(self) -> None:
        analyze.atomic_json(self.target, {'phase': 'enrich'})
        self.assertEqual(json.loads(self.target.read_text(encoding='utf-8')),
                         {'phase': 'enrich'})


class CacheNormalizationTests(unittest.TestCase):
    def test_legacy_state_normalization_does_not_mutate_input(self) -> None:
        previous = {'row': {'relative_path': 'system/job.log', 'job_name': 'job'},
                    'signature': [13, 1, 1]}
        current = analyze.normalize_cached_entry(previous)
        self.assertEqual(current['row']['path'], 'system/job.log')
        self.assertNotIn('relative_path', current['row'])
        self.assertNotIn('path', previous['row'])
        self.assertIn('relative_path', previous['row'])

    def test_incomplete_checkpoint_is_not_cached_after_quiet_period(self) -> None:
        now = datetime(2026, 10, 8, tzinfo=timezone.utc)
        signature = [100, int(now.timestamp() - 1000) * 1_000_000_000, 7]
        row = {field: '' for field in analyze.CSV_FIELDS}
        row['enrichment_status'] = 'Enriched'
        state = {'signature': signature, 'row': row,
                 'checkpoint': {'offset': 80, 'tail_included': False}}
        self.assertFalse(analyze.reusable_enrichment(
            state, signature, now=now, recent_minutes=5))
        state['checkpoint']['tail_included'] = True
        self.assertTrue(analyze.reusable_enrichment(
            state, signature, now=now, recent_minutes=5))
        state['row'].pop('duration')
        self.assertFalse(analyze.reusable_enrichment(
            state, signature, now=now, recent_minutes=5))


class ProcessSchedulerBoundaryTests(unittest.TestCase):
    def test_progress_callback_and_multiple_snapshots(self) -> None:
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        base = Path(temporary.name)
        host = base / 'host'
        cob = '20261007'
        names = ['DataPlatform_20261007_Thursday', 'DataPlatform_20261007_Friday']
        for name in names:
            log = host / cob / name / 'job.log'
            log.parent.mkdir(parents=True)
            log.write_text('2026-10-07 12:00:00,001 INFO : Start\n', encoding='utf-8')
        settings = {'environments': {'U5': {'logs_root': 'unused', 'process_scheduler': {
            'share': 'RALogs', 'hosts': [{'name': 'host.example.org', 'root': str(host)}],
            'default_topology': 'DataPlatform',
        }}}, 'incremental': {'read_workers': 2}}
        dashboard = MagicMock()
        result = ps.extract(config=settings, config_dir=base, environment='U5',
                            topology='DataPlatform', output_dir=base / 'output',
                            encoding='utf-8-sig', now=datetime(2026, 10, 8, tzinfo=timezone.utc),
                            progress=dashboard)
        self.assertEqual(result, 0)
        dashboard.begin_cob.assert_called_once_with(cob, 1)
        dashboard.set_file_total.assert_called_once_with(2)
        dashboard.end_cob.assert_called_once_with(written=True)
        for name in names:
            report = base / 'output' / 'U5' / 'process_scheduler' / 'DataPlatform' / cob / name / ps.report_filename('U5', cob, name, 'jobs', 'csv', created_at=datetime(2026, 10, 8, tzinfo=timezone.utc))
            self.assertTrue(report.exists(), report)


if __name__ == '__main__':
    unittest.main()
