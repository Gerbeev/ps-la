"""Process Scheduler report presentation and diagnostic durability contract."""
from __future__ import annotations

import csv
from datetime import datetime, timezone
from io import StringIO
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
from zipfile import ZipFile
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import process_scheduler as ps
import excel_export
import analyze

COB = '20261007'
TOPO = 'DataPlatform_20261007_Thursday'
NOW = datetime(2026, 10, 8, 12, tzinfo=timezone.utc)


class ReportPublicationTests(unittest.TestCase):
    def setUp(self) -> None:
        temp = TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.share = self.root / 'online'
        self.source = self.share / COB / TOPO / 'job.log'
        self.source.parent.mkdir(parents=True)
        self.source.write_text('2026-10-07 11:00:01,000 [1] ERROR : fail\n'
                               'Exception details\nStack frame\n', encoding='utf-8')
        self.output = self.root / 'output'
        self.report_dir = self.output / 'U5' / 'process_scheduler' / 'DataPlatform' / COB / TOPO
        self.diag_root = self.output / 'logs' / 'U5' / COB / TOPO
        self.hosts = [{'name': 'online.example.org', 'root': str(self.share)}]

    def invoke(self, fmt: str = 'csv') -> tuple[int, str, str]:
        config = {'environments': {'U5': {'process_scheduler': {
            'share': 'RALogs', 'hosts': self.hosts,
            'default_topology': 'DataPlatform',
        }}}}
        stdout, stderr = StringIO(), StringIO()
        result = ps.extract(config=config, config_dir=self.root, environment='U5',
                            topology=TOPO, output_dir=self.output,
                            encoding='utf-8-sig', now=NOW, output_format=fmt,
                            stdout=stdout, stderr=stderr)
        return result, stdout.getvalue(), stderr.getvalue()

    def reports(self, fmt: str = 'csv') -> tuple[Path, Path]:
        return (self.report_dir / ps.report_filename('U5', COB, TOPO, 'jobs', fmt, created_at=NOW),
                self.report_dir / ps.report_filename('U5', COB, TOPO, 'duplicates', fmt, created_at=NOW))

    def latest(self) -> dict:
        return json.loads((self.diag_root / 'latest.json').read_text(encoding='utf-8'))

    def test_filename_complete_diagnostics_and_no_work_files(self):
        status, output, _ = self.invoke()
        self.assertEqual(status, 0)
        jobs, duplicates = self.reports()
        self.assertTrue(jobs.exists())
        self.assertTrue(duplicates.exists())
        self.assertIn('U5_DataPlatform_20261007_Thursday_20261008_12-00-00.csv', output)
        self.assertEqual(sorted(path.name for path in self.report_dir.iterdir()),
                         sorted([jobs.name, duplicates.name]))
        latest = self.latest()
        self.assertEqual(latest['status'], 'Completed')
        run_file = Path(latest['diagnostics'])
        run = json.loads(run_file.read_text(encoding='utf-8'))
        self.assertEqual(run['status'], 'Completed')
        self.assertEqual(run['included_logs'], 1)
        self.assertEqual(run['inaccessible_hosts'], 0)
        self.assertEqual(run['reports'], [str(jobs), str(duplicates)])
        self.assertIn('No source access', run_file.with_name('issues.log').read_text())
        self.assertEqual(list(self.diag_root.rglob('*.work.*')), [])

    def test_unavailable_host_still_publishes_normal_filename_with_run_warning(self):
        self.hosts.append({'name': 'offline.example.org', 'root': str(self.root / 'missing')})
        code, output, err = self.invoke()
        jobs, duplicates = self.reports()
        self.assertEqual(code, 2)
        self.assertIn('COMPLETED WITH WARNINGS', err)
        self.assertIn('CompletedWithWarnings', output)
        self.assertTrue(jobs.exists())
        self.assertTrue(duplicates.exists())
        self.assertFalse(list(self.report_dir.glob('*.partial.*')))
        with jobs.open(encoding='utf-8-sig', newline='') as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(len(rows), 1)
        run = json.loads(Path(self.latest()['diagnostics']).read_text())
        self.assertEqual(run['status'], 'CompletedWithWarnings')
        self.assertEqual(run['inaccessible_hosts'], 1)
        self.assertIn('offline.example.org', Path(run['issues_log']).read_text())

    def test_complete_report_archived_before_warning_replaces_latest(self):
        self.assertEqual(self.invoke()[0], 0)
        original = self.reports()[0].read_bytes()
        self.source.write_text('2026-10-07 14:00:00,000 [1] ERROR : second\n', encoding='utf-8')
        self.hosts.append({'name': 'offline.example.org', 'root': str(self.root / 'missing')})
        self.assertEqual(self.invoke()[0], 2)
        fresh = self.reports()[0].read_bytes()
        self.assertNotEqual(fresh, original)
        backup = self.diag_root / '_last_complete' / 'jobs.csv'
        self.assertEqual(backup.read_bytes(), original)
        self.assertEqual(self.latest()['status'], 'CompletedWithWarnings')
        self.assertIn(str(backup), self.latest()['previous_complete_backups'])
        # A second warned run must not turn the preserved complete file into a warning snapshot.
        self.assertEqual(self.invoke()[0], 2)
        self.assertEqual(backup.read_bytes(), original)

    def test_legacy_partial_and_complete_removed_from_visible_folder(self):
        self.report_dir.mkdir(parents=True)
        (self.report_dir / 'jobs.partial.xlsx').write_bytes(b'old partial')
        (self.report_dir / 'duplicates.partial.csv').write_bytes(b'old partial')
        (self.report_dir / 'issues.partial.txt').write_text('old issues')
        (self.report_dir / 'jobs.csv').write_text('old complete')
        self.hosts.append({'name': 'offline.example.org', 'root': str(self.root / 'missing')})
        self.assertEqual(self.invoke()[0], 2)
        self.assertEqual(sorted(path.name for path in self.report_dir.iterdir()),
                         sorted(path.name for path in self.reports()))
        self.assertEqual((self.diag_root / '_last_complete' / 'jobs.csv').read_text(),
                         'old complete')

    def test_warning_excel_still_has_filters_frozen_header_fixed_height(self):
        self.hosts.append({'name': 'offline.example.org', 'root': str(self.root / 'missing')})
        self.assertEqual(self.invoke('xlsx')[0], 2)
        jobs, duplicates = self.reports('xlsx')
        self.assertTrue(jobs.is_file())
        self.assertTrue(duplicates.is_file())
        self.assertEqual(list(self.report_dir.glob('*.csv')), [])
        with ZipFile(jobs) as book:
            sheet = ET.fromstring(book.read('xl/worksheets/sheet1.xml'))
            ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            self.assertIsNotNone(sheet.find('.//s:autoFilter', ns))
            self.assertIsNotNone(sheet.find('.//s:pane', ns))
            self.assertEqual(sheet.find('.//s:sheetData/s:row[@r="2"]', ns).attrib['ht'], '19')
            self.assertIn(b'Exception details', book.read('xl/worksheets/sheet1.xml'))
        self.assertEqual(list(self.diag_root.rglob('*.work.*')), [])

    def test_export_failure_preserves_last_published_report_and_writes_issue_log(self):
        self.assertEqual(self.invoke('xlsx')[0], 0)
        existing = self.reports('xlsx')[0].read_bytes()
        with patch.object(excel_export, 'export_csv_to_xlsx', side_effect=ValueError('injected workbook failure')):
            with self.assertRaisesRegex(ValueError, 'injected workbook failure'):
                self.invoke('xlsx')
        self.assertEqual(self.reports('xlsx')[0].read_bytes(), existing)
        self.assertEqual(self.latest()['status'], 'Completed')
        all_run_files = sorted(self.diag_root.glob('*/run.json'))
        self.assertEqual(len(all_run_files), 2)
        statuses = {json.loads(path.read_text())['status'] for path in all_run_files}
        self.assertEqual(statuses, {'Completed', 'ExportFailed'})
        failed = next(path for path in all_run_files if 'ExportFailed' in path.read_text())
        self.assertIn('injected workbook failure', failed.with_name('issues.log').read_text())
        self.assertEqual(list(self.diag_root.rglob('*.work.*')), [])

    def test_no_accessible_host_writes_diagnostics_but_no_report(self):
        self.hosts = [{'name': 'offline.example.org', 'root': str(self.root / 'missing')}]
        with self.assertRaisesRegex(ValueError, 'No Process Scheduler hosts accessible'):
            self.invoke()
        self.assertFalse(self.report_dir.exists())
        all_runs = list(self.diag_root.glob('*/run.json'))
        self.assertEqual(len(all_runs), 1)
        self.assertEqual(json.loads(all_runs[0].read_text())['status'], 'Failed')
        self.assertIn('offline.example.org', all_runs[0].with_name('issues.log').read_text())

    def test_format_switch_leaves_only_latest_visible_extension(self):
        self.assertEqual(self.invoke('xlsx')[0], 0)
        self.assertTrue(self.reports('xlsx')[0].is_file())
        self.assertEqual(self.invoke('csv')[0], 0)
        self.assertTrue(self.reports('csv')[0].is_file())
        self.assertFalse(self.reports('xlsx')[0].exists())
        self.assertEqual(self.invoke('xlsx')[0], 0)
        self.assertTrue(self.reports('xlsx')[0].is_file())
        self.assertFalse(self.reports('csv')[0].exists())


if __name__ == '__main__':
    unittest.main()
