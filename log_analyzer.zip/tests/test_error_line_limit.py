"""Configurable ERROR continuation limit across all extraction paths."""
from __future__ import annotations

import csv
import json
import os
import sys
import unittest
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import analyze
import menu
import process_scheduler

PREFIX = '2026-10-08 10:00:00,111 [1] ERROR : Failure'
DETAILS = [f'  detail {i}' for i in range(1, 9)]
TEXT = '\n'.join([PREFIX, *DETAILS, '2026-10-08 10:01:00,000 [1] INFO : Finished']) + '\n'
NOW = datetime(2026, 10, 9, 12, tzinfo=timezone.utc)


class ErrorLineLimitTests(unittest.TestCase):
    def setUp(self) -> None:
        tmp = TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.base = Path(tmp.name)
        self.log = self.base / 'error.log'
        self.log.write_text(TEXT, encoding='utf-8')

    def test_default_five_lines_and_error_not_counted_in_limit(self) -> None:
        result = analyze.analyze_log(self.log, '20261007')
        self.assertEqual(result.last_error, '\n'.join([PREFIX, *DETAILS[:5]]))
        self.assertEqual(result.error_count, 1)
        self.assertEqual(result.end_time, '2026-10-08 10:01:00.000')

    def test_custom_zero_two_and_high_limits(self) -> None:
        for count, expected in [(0, [PREFIX]), (2, [PREFIX, *DETAILS[:2]]),
                                (50, [PREFIX, *DETAILS])]:
            with self.subTest(count=count):
                result = analyze.analyze_log(self.log, '20261007', error_following_lines=count)
                self.assertEqual(result.last_error, '\n'.join(expected))

    def test_stop_at_timestamp_even_when_budget_left(self) -> None:
        self.log.write_text(PREFIX + '\nline 1\n2026/10/08 10:01:00 NOTICE : done\nline 2\n', encoding='utf-8')
        result = analyze.analyze_log(self.log, '20261007', error_following_lines=5)
        self.assertEqual(result.last_error, PREFIX + '\nline 1')

    def test_eof_without_timestamp_uses_same_limit(self) -> None:
        self.log.write_text('\n'.join([PREFIX, *DETAILS]), encoding='utf-8')
        result = analyze.analyze_log(self.log, '20261007', error_following_lines=5)
        self.assertEqual(result.last_error, '\n'.join([PREFIX, *DETAILS[:5]]))

    def test_incremental_checkpoint_does_not_extend_beyond_limit(self) -> None:
        self.log.write_text('\n'.join([PREFIX, *DETAILS[:3]]) + '\n', encoding='utf-8')
        with analyze.open_shared_log(self.log) as stream:
            _, state, _ = analyze._scan_from(stream, start_offset=0,
                limit=self.log.stat().st_size, encoding='utf-8-sig',
                initial=analyze._new_accumulator(), include_tail=False,
                file_path=self.log, job_date='20261007', system='', error_following_lines=5)
        with self.log.open('a', encoding='utf-8') as stream:
            stream.write('\n'.join(DETAILS[3:]) + '\n')
        with analyze.open_shared_log(self.log) as stream:
            summary, state, _ = analyze._scan_from(stream,
                start_offset=state['offset'], limit=self.log.stat().st_size,
                encoding='utf-8-sig', initial=state, include_tail=False,
                file_path=self.log, job_date='20261007', system='', error_following_lines=5)
        self.assertEqual(summary.last_error, '\n'.join([PREFIX, *DETAILS[:5]]))
        self.assertEqual(len(state['last_error_lines']), 6)

    def test_config_validation_and_fallback(self) -> None:
        self.assertEqual(analyze.error_following_lines_from_config({}), 5)
        for bad in (True, -1, 1001, '5', None, 1.5):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                analyze.validate_config({'environments': {}, 'parsing': {'error_following_lines': bad}})
        with self.assertRaisesRegex(ValueError, 'parsing must be'):
            analyze.error_following_lines_from_config({'parsing': []})

    def test_menu_updates_shared_config(self) -> None:
        path = self.base / 'config.json'
        path.write_text(json.dumps({'environments': {'U5': {'logs_root': 'unused'}}}), encoding='utf-8')
        choices = iter(['9', '9', '2', '0', '0'])
        display = StringIO()
        app = menu.ConsoleMenu(config_path=path, read=lambda prompt: next(choices), output=display)
        self.assertEqual(app.run(), 0)
        self.assertIn('9. Max lines after ERROR', display.getvalue())
        self.assertEqual(json.loads(path.read_text())['parsing']['error_following_lines'], 2)

    def test_process_scheduler_csv_uses_configured_limit(self) -> None:
        folder = 'DataPlatform_20261007_Thursday'
        source = self.base / 'host' / '20261007' / folder / 'job.log'
        source.parent.mkdir(parents=True)
        source.write_text(TEXT, encoding='utf-8')
        config = {'parsing': {'error_following_lines': 2}, 'incremental': {'read_workers': 1},
                  'environments': {'U5': {'logs_root': 'unused', 'process_scheduler': {
                      'share': 'RALogs', 'default_topology': 'DataPlatform',
                      'hosts': [{'name': 'agent.example.org', 'root': str(self.base / 'host')}],
                      'host_aliases': {}}}}}
        result = process_scheduler.extract(config=config, config_dir=self.base, environment='U5',
                   topology=folder, output_dir=self.base / 'output', encoding='utf-8-sig',
                   now=NOW, stdout=StringIO(), stderr=StringIO())
        self.assertEqual(result, 0)
        path = self.base / 'output' / 'U5' / 'process_scheduler' / 'DataPlatform' / '20261007' / folder / process_scheduler.report_filename('U5', '20261007', folder, 'jobs', 'csv', created_at=NOW)
        with path.open(encoding='utf-8-sig', newline='') as stream:
            row = next(csv.DictReader(stream))
        self.assertEqual(row['last_error'], '\n'.join([PREFIX, *DETAILS[:2]]))
        self.assertEqual(row['error_count'], '1')

    def test_changing_setting_reparses_cached_rows_including_closed_cob(self) -> None:
        cob = '20261007'
        log = self.base / 'Logs' / cob / 'System' / 'error.log'
        log.parent.mkdir(parents=True)
        log.write_text(TEXT, encoding='utf-8')
        output = self.base / 'out'
        date = datetime(2026, 10, 20, 12, tzinfo=timezone.utc)
        old = datetime(2026, 10, 8, 10, tzinfo=timezone.utc).timestamp()
        os.utime(log, (old, old))

        def run(count: int):
            return analyze.write_csv(root=self.base / 'Logs', output_dir=output,
                environment='U5', encoding='utf-8-sig', only_date=cob, delimiter=',',
                error_following_lines=count, now=date, policy=analyze.IncrementalPolicy(),
                stdout=StringIO(), stderr=StringIO())

        first = run(2)
        self.assertEqual(first[0], 1)
        report = output / 'U5' / '.state' / 'report_csv' / f'{cob}.csv'
        with report.open(encoding='utf-8-sig', newline='') as stream:
            self.assertEqual(next(csv.DictReader(stream))['last_error'], '\n'.join([PREFIX, *DETAILS[:2]]))
        state = output / 'U5' / '.state' / f'{cob}.json'
        self.assertEqual(json.loads(state.read_text())['status'], 'closed')
        self.assertEqual(run(2)[0], 0)
        self.assertEqual(run(5)[0], 1)
        with report.open(encoding='utf-8-sig', newline='') as stream:
            self.assertEqual(next(csv.DictReader(stream))['last_error'], '\n'.join([PREFIX, *DETAILS[:5]]))


if __name__ == '__main__':
    unittest.main()
