"""Durable, replace-on-success writes for local reports and configuration."""

from __future__ import annotations

from contextlib import contextmanager
import os
from pathlib import Path
import shutil
import tempfile
from typing import Iterator, TextIO


@contextmanager
def atomic_text_writer(
    target: Path, *, encoding: str, newline: str,
    prefix: str,
) -> Iterator[TextIO]:
    """Write to a same-directory temporary file and publish only after fsync.

    A failed serializer, interrupted write, or failed replacement leaves the
    previously published target untouched and removes the temporary file.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding=encoding, newline=newline,
            dir=target.parent, prefix=prefix, suffix=".tmp", delete=False,
        ) as stream:
            temporary = Path(stream.name)
            yield stream
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def atomic_binary_copy(source: Path, destination: Path, *, prefix: str) -> None:
    """Copy a file without exposing a partially written destination.

    Both report-format publishing and last-complete backups need the same
    write/flush/replace guarantees. The temporary file stays beside the
    destination so os.replace remains atomic on the target filesystem.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with source.open('rb') as original, tempfile.NamedTemporaryFile(
            dir=destination.parent, prefix=prefix, suffix='.tmp', delete=False,
        ) as stored:
            temporary = Path(stored.name)
            shutil.copyfileobj(original, stored)
            stored.flush()
            os.fsync(stored.fileno())
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
