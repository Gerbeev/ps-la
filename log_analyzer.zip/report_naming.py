"""Windows-safe, timestamped names for user-visible report artifacts."""
from __future__ import annotations

from datetime import datetime
import re

_VALID_COMPONENT = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,199}\Z')


def report_name(environment: str, source: str, created_at: datetime,
                extension: str, *, kind: str = 'jobs') -> str:
    """<ENV>_<source>_<YYYYMMDD>_<HH-mm-ss>.<extension>.

    A colon is prohibited in Windows filenames. The suffix for supplemental
    duplicates reports prevents them from colliding with the main report.
    """
    if not re.fullmatch(r'[A-Z][A-Z0-9]{1,9}', environment):
        raise ValueError('Invalid report environment')
    if not _VALID_COMPONENT.fullmatch(source):
        raise ValueError('Invalid report source')
    if extension not in ('csv', 'xlsx') or kind not in ('jobs', 'duplicates'):
        raise ValueError('Invalid report type or extension')
    suffix = '' if kind == 'jobs' else '_duplicates'
    return f'{environment}_{source}{suffix}_{created_at.strftime("%Y%m%d_%H-%M-%S")}.{extension}'
