#!/usr/bin/env python3
"""Read-only Process Scheduler host fan-out, content deduplication and CSV/XLSX export.

Requires Python 3.11+, stdlib only. Does not call the scheduler's internal API:
its topology URL documents the topology, while configured agents supply UNC roots.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
import csv
import json
import os
from pathlib import Path
import re
import sys
from typing import TextIO
from urllib.parse import quote, urlsplit, urlunsplit

import analyze
from atomic_io import atomic_binary_copy, atomic_text_writer
import excel_export
from report_naming import report_name
from progress import ConsoleProgress

HOST_NAME = re.compile(r"^[a-zA-Z0-9](?:[a-zA-Z0-9.-]{0,251}[a-zA-Z0-9])?$")
TOPOLOGY_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$")
FULL_TOPOLOGY = re.compile(r"^(?P<base>.+)_(?P<cob>\d{8})_(?P<suffix>[A-Za-z][A-Za-z0-9_-]*)$")
ENGLISH_WEEKDAYS = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')


@dataclass(frozen=True)
class Agent:
    host: str
    root: Path
    canonical: str


@dataclass(frozen=True)
class SourceLog:
    cob: str
    topology: str
    relative: str
    host: str
    path: Path
    stat: os.stat_result


@dataclass
class SourceResult:
    rows: list[dict]
    duplicates: list[tuple[str, str, str]]
    failures: list[str]
    conflicts: int = 0
    missing_timestamps: int = 0


def configured_environments(config: dict) -> list[str]:
    return [env for env in analyze.ALLOWED_ENVIRONMENTS
            if env in config.get('environments', {})
            and isinstance(config['environments'][env].get('process_scheduler'), dict)]


def _topology_url_base(settings: dict) -> str:
    """Return an HTTPS topology index URL, including for older config files.

    Historical configs stored a link to a particular dated topology instead of
    the index URL.  Keep accepting them, but never expose that historical name
    in the link presented for the user's selected topology.
    """
    base = settings.get('topology_base_url')
    legacy = base is None
    url = settings.get('topology_url', '') if legacy else base
    if not isinstance(url, str):
        raise ValueError('topology_base_url must be a string')
    if not url:
        return ''
    try:
        parts = urlsplit(url)
        host = parts.hostname
        port = parts.port
    except ValueError as exc:
        raise ValueError('invalid topology HTTPS URL') from exc
    if (parts.scheme != 'https' or not host or parts.username is not None
            or parts.password is not None or parts.query or parts.fragment or port == 0):
        raise ValueError('topology_base_url must be an HTTPS URL without credentials/query/fragment')
    path = parts.path
    if legacy and path.rstrip('/').rsplit('/', 1)[-1] != 'Index':
        path = path.rsplit('/', 1)[0]
    if not path.endswith('/Topology/Index') and not path.endswith('/Topology/Index/'):
        raise ValueError('topology URL must point to /Topology/Index/')
    return urlunsplit((parts.scheme, parts.netloc, path.rstrip('/') + '/', '', ''))


def topology_reference_url(settings: dict, topology: str) -> str:
    """Build a reference link for the selected topology, never a stale one."""
    _, _, exact_folder = parse_topology(topology)
    if exact_folder is None:
        return ''  # Base-name scans can match several folders, not one URL.
    base = _topology_url_base(settings)
    return base + quote(topology, safe='') if base else ''


def settings_for(config: dict, environment: str, *, config_dir: Path) -> tuple[dict, list[list[Agent]]]:
    entry = config['environments'].get(environment, {})
    settings = entry.get('process_scheduler')
    if not isinstance(settings, dict):
        raise ValueError(f'{environment}: process_scheduler is not configured')
    share = settings.get('share')
    if not isinstance(share, str) or not re.fullmatch(r'[A-Za-z0-9_$-]{1,80}', share):
        raise ValueError(f'{environment}: invalid process_scheduler.share')
    _topology_url_base(settings)
    default_topology = settings.get('default_topology', '')
    if not isinstance(default_topology, str) or (default_topology and not TOPOLOGY_NAME.fullmatch(default_topology)):
        raise ValueError(f'{environment}: invalid default_topology')
    hosts = settings.get('hosts')
    if not isinstance(hosts, list) or not hosts:
        raise ValueError(f'{environment}: process_scheduler.hosts must be a non-empty list')
    aliases = settings.get('host_aliases', {})
    if not isinstance(aliases, dict) or any(not isinstance(k, str) or not isinstance(v, str)
            or not HOST_NAME.fullmatch(k) or not HOST_NAME.fullmatch(v) for k, v in aliases.items()):
        raise ValueError(f'{environment}: invalid host_aliases dictionary')
    aliases = {k.lower(): v.lower() for k, v in aliases.items()}
    unique_names: set[str] = set()
    groups: dict[str, list[Agent]] = {}
    for host_entry in hosts:
        if not isinstance(host_entry, dict):
            raise ValueError(f'{environment}: host entries must be objects')
        name = host_entry.get('name')
        if not isinstance(name, str) or not HOST_NAME.fullmatch(name):
            raise ValueError(f'{environment}: invalid agent hostname {name!r}')
        name = name.lower()
        if name in unique_names:
            raise ValueError(f'{environment}: duplicate configured hostname: {name}')
        unique_names.add(name)
        enabled = host_entry.get('enabled', True)
        if type(enabled) is not bool:
            raise ValueError(f'{environment}: host.enabled must be boolean')
        root_override = host_entry.get('root')
        if root_override is not None and (not isinstance(root_override, str) or not root_override.strip()):
            raise ValueError(f'{environment}: host.root must be non-empty if supplied')
        if not enabled:
            continue
        if root_override:
            root = Path(os.path.expandvars(os.path.expanduser(root_override)))
            if not root.is_absolute():
                root = config_dir / root
        else:
            root = Path(f'\\\\{name}\\{share}')
        canonical = aliases.get(name, name)
        # Explicit aliases are tried as failover sources for one physical share.
        groups.setdefault(canonical, []).append(Agent(name, root, canonical))
    if not groups:
        raise ValueError(f'{environment}: no enabled Process Scheduler agents')
    return settings, list(groups.values())


def validate_settings(config: dict) -> None:
    for environment in configured_environments(config):
        settings_for(config, environment, config_dir=Path('.'))


def parse_topology(value: str) -> tuple[str, str | None, str | None]:
    value = value.strip()
    if not TOPOLOGY_NAME.fullmatch(value):
        raise ValueError('Topology must contain only letters, digits, underscore or dash (no path or URL)')
    full = FULL_TOPOLOGY.fullmatch(value)
    if full and analyze.valid_cob(full['cob']):
        return full['base'], full['cob'], value
    return value, None, None


def default_topology_name(base: str, *, current_day: date | None = None) -> str:
    """Build the daily topology: yesterday's COB + today's English weekday.

    Use the computer's local date, not the locale-dependent %A formatter.
    For Thursday 2026-10-08 this yields DataPlatform_20261007_Thursday.
    """
    if not isinstance(base, str) or not TOPOLOGY_NAME.fullmatch(base):
        raise ValueError('Process Scheduler default_topology must be a valid base name')
    current_day = current_day if current_day is not None else date.today()
    cob = (current_day - timedelta(days=1)).strftime('%Y%m%d')
    full_name = f'{base}_{cob}_{ENGLISH_WEEKDAYS[current_day.weekday()]}'
    if parse_topology(full_name)[2] != full_name:
        raise ValueError('Generated topology name is invalid')
    return full_name


def _scandir_directories(directory: Path) -> list[str]:
    names = []
    with os.scandir(directory) as iterator:
        for item in iterator:
            if not item.is_symlink() and item.is_dir(follow_symlinks=False):
                names.append(item.name)
    return sorted(names)


def _discover_agent_cobs(agent: Agent, now: datetime, only_date: str | None) -> dict[str, Path]:
    names = _scandir_directories(agent.root)
    today = now.strftime('%Y%m%d')
    return {name: agent.root / name for name in names
            if analyze.valid_cob(name) and name <= today and (not only_date or only_date == name)}


def _process_group(copies: list[SourceLog], encoding: str, now: datetime, recent_minutes: int,
                   error_following_lines: int = analyze.DEFAULT_ERROR_FOLLOWING_LINES) -> SourceResult:
    output = SourceResult([], [], [])
    # Each physical copy is parsed against its own open-time bounded snapshot.
    # Directory enumeration metadata is only a discovery hint: live loggers may
    # append at any point between enumeration and reading.
    winners: dict[tuple[int, bytes], SourceLog] = {}
    multiple_copies = len(copies) > 1
    for copy in copies:
        try:
            parsed = analyze.stable_summary(
                copy.path, copy.cob, copy.topology, encoding,
                now=now, recent_minutes=recent_minutes,
                hash_snapshot=multiple_copies,
                error_following_lines=error_following_lines,
            )
            if parsed is None:
                raise OSError('source was truncated, replaced or rewritten while reading')
            identity = (parsed.signature[0], parsed.content_digest or b'')
            if multiple_copies and identity in winners:
                winner = winners[identity]
                output.duplicates.append((copy.relative, str(winner.path), str(copy.path)))
                continue
            row = analyze.enriched_row(
                parsed.summary, parsed.signature, str(copy.path),
                now=now, recent_minutes=recent_minutes, host=copy.host,
            )
            if not parsed.summary.start_time or not parsed.summary.end_time:
                output.missing_timestamps += 1
            output.rows.append(row)
            if multiple_copies:
                winners[identity] = copy
        except (OSError, UnicodeError, ValueError) as exc:
            output.failures.append(f'SKIP: {copy.path}: parsing failed: {exc}')
    output.conflicts = int(len(output.rows) > 1)
    return output


def _atomic_duplicates(path: Path, duplicates: list[tuple[str, str, str]]) -> None:
    with atomic_text_writer(path, encoding='utf-8-sig', newline='', prefix='.duplicates-') as stream:
        writer = csv.writer(stream)
        writer.writerow(('relative_log_path', 'retained_source', 'duplicate_source'))
        for relative, kept, duplicate in duplicates:
            writer.writerow(tuple(analyze.excel_safe(value) for value in (relative, kept, duplicate)))


def _atomic_issues(path: Path, messages: list[str]) -> None:
    """Persist all errors without flooding the user's interactive console."""
    with atomic_text_writer(path, encoding='utf-8', newline='\n', prefix='.issues-') as stream:
        for message in messages:
            stream.write(message.replace('\r', ' ').replace('\n', ' ') + '\n')


def _print_cob_failures(cob: str, failures: list[str], stderr: TextIO) -> None:
    if len(failures) <= 8:
        for message in failures:
            print(message, file=stderr)
        return
    reasons = Counter(message.rsplit(': ', 1)[-1] for message in failures)
    summary = '; '.join(f'{count}x {reason}' for reason, count in reasons.most_common(4))
    print(f'WARN: COB {cob}: {len(failures)} file/directory errors; reasons: {summary}', file=stderr)
    for message in failures[:5]:
        print(message, file=stderr)
    print(f'WARN: {len(failures) - 5} additional errors; full list saved to output/logs/', file=stderr)


@dataclass
class CobExtraction:
    rows: dict[str, dict]
    duplicates: list[tuple[str, str, str]]
    failures: list[str]
    conflicts: int = 0
    missing_timestamps: int = 0


def _discover_hosts(
    groups: list[list[Agent]], now: datetime, only_date: str | None,
    stdout: TextIO, stderr: TextIO, progress: ConsoleProgress | None,
) -> tuple[list[tuple[Agent, dict[str, Path]]], list[str]]:
    """Try one reachable UNC alias per physical host without double-scanning it."""
    discovered: list[tuple[Agent, dict[str, Path]]] = []
    failures: list[str] = []
    for group in groups:
        failed_aliases: list[str] = []
        for agent in group:
            if progress:
                progress.message(f'Discovering host: {agent.host}', error=False)
            try:
                date_folders = _discover_agent_cobs(agent, now, only_date)
            except OSError as exc:
                failed_aliases.append(f'{agent.host}: {exc}')
                continue
            discovered.append((agent, date_folders))
            print(f'HOST: {agent.host}: {len(date_folders)} COB directories', file=stdout)
            break
        else:
            failures.append('WARN: HOST UNAVAILABLE: ' + ' / '.join(failed_aliases))
    for message in failures:
        print(message, file=stderr)
    return discovered, failures


def _collect_cob_logs(
    cob: str, agents: list[tuple[Agent, dict[str, Path]]],
    base: str, exact_folder: str | None,
) -> tuple[dict[tuple[str, str], list[SourceLog]], list[str]]:
    """Discover logical logs across hosts; retain no partial folder listing."""
    logical: dict[tuple[str, str], list[SourceLog]] = defaultdict(list)
    failures: list[str] = []
    for agent, dates in agents:
        parent = dates.get(cob)
        if parent is None:
            continue
        try:
            folders = _scandir_directories(parent)
            matches = ([name for name in folders if name == exact_folder]
                       if exact_folder else [name for name in folders
                       if name == base or name.startswith(f'{base}_{cob}_')])
            for folder_name in matches:
                folder = parent / folder_name
                sources = [
                    SourceLog(cob, folder_name, path.relative_to(folder).as_posix(),
                              agent.host, path, metadata)
                    for path, metadata in analyze.iter_log_files(folder)
                ]
                for source in sources:
                    logical[(source.topology.casefold(), source.relative.casefold())].append(source)
        except OSError as exc:
            failures.append(f'WARN: HOST READ FAILED: {agent.host} / COB {cob}: {exc}')
    return logical, failures


def _enrich_cob_logs(
    logical: dict[tuple[str, str], list[SourceLog]], *,
    encoding: str, now: datetime, recent_minutes: int, workers: int,
    progress: ConsoleProgress | None,
    error_following_lines: int = analyze.DEFAULT_ERROR_FOLLOWING_LINES,
) -> CobExtraction:
    """Process bounded SMB reads; consolidate one result per logical filename."""
    extraction = CobExtraction({}, [], [])
    if progress:
        progress.set_file_total(len(logical))

    pending: deque[tuple[str, Future[SourceResult]]] = deque()

    def consume() -> None:
        key, task = pending.popleft()
        result = task.result()
        extraction.missing_timestamps += result.missing_timestamps
        extraction.conflicts += result.conflicts
        extraction.failures.extend(result.failures)
        extraction.duplicates.extend(result.duplicates)
        for row in result.rows:
            extraction.rows[row['path'].casefold()] = {'row': row}
        if progress:
            progress.file_completed('enriched' if result.rows else 'skipped', key)

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix='ps-log') as pool:
        for key in sorted(logical):
            copies = logical[key]
            key = f'{copies[0].topology}/{copies[0].relative}'
            if progress:
                progress.file_queued(key)
            pending.append((key, pool.submit(_process_group, copies, encoding, now,
                                             recent_minutes, error_following_lines)))
            if len(pending) >= 2 * workers:
                consume()
        while pending:
            consume()
    return extraction


def report_filename(environment: str, cob: str, topology: str, kind: str, fmt: str,
                    *, created_at: datetime | None = None) -> str:
    """Windows-safe report filename; COB is validated, timestamp is export time."""
    if environment not in analyze.ALLOWED_ENVIRONMENTS or not analyze.valid_cob(cob):
        raise ValueError('Invalid report environment or COB')
    if not TOPOLOGY_NAME.fullmatch(topology):
        raise ValueError('Invalid report topology')
    return report_name(environment, topology,
                       created_at or datetime.now().astimezone(), fmt, kind=kind)


def _diagnostics_dir(output_dir: Path, environment: str, cob: str,
                     topology: str, run_id: str) -> Path:
    return output_dir / 'logs' / environment / cob / topology / run_id


def _atomic_backup(source: Path, destination: Path) -> None:
    """Preserve the last complete artifact without corrupting older backups on I/O failure."""
    atomic_binary_copy(source, destination, prefix='.backup-')


def _write_diagnostics(directory: Path, *, environment: str, cob: str,
                       topology: str, status: str, failures: list[str],
                       report_paths: list[Path], row_count: int,
                       duplicate_count: int, missing_timestamps: int,
                       conflicts: int, host_failures: int, file_failures: int,
                       started_at: str, finished_at: str,
                       previous_complete_backups: list[Path] | None = None) -> None:
    """Every run has a machine-readable outcome; issues are kept out of report folders."""
    directory.mkdir(parents=True, exist_ok=True)
    _atomic_issues(directory / 'issues.log', failures or ['No source access or read errors.'])
    analyze.atomic_json(directory / 'run.json', {
        'environment': environment, 'cob': cob, 'topology': topology,
        'status': status, 'started_at_utc': started_at,
        'finished_at_utc': finished_at,
        'included_logs': row_count, 'duplicate_copies': duplicate_count,
        'logs_without_timestamps': missing_timestamps,
        'content_conflicts': conflicts,
        'inaccessible_hosts': host_failures, 'file_directory_errors': file_failures,
        'issues_log': str(directory / 'issues.log'),
        'reports': [str(path) for path in report_paths],
        'previous_complete_backups': [str(path) for path in (previous_complete_backups or [])],
    })


def _publish_cob_reports(
    *, env_dir: Path, base: str, cob: str, rows: dict[str, dict],
    duplicates: list[tuple[str, str, str]], partial: bool, failures: list[str],
    delimiter: str, stdout: TextIO, output_format: str = 'csv',
    environment: str = 'U5', output_dir: Path | None = None,
    run_id: str | None = None, started_at: str = '',
    report_at: datetime | None = None,
    missing_timestamps: int = 0, conflicts: int = 0,
    host_failures: int = 0, file_failures: int = 0,
) -> int:
    """Publish one current report per topology, independently of source availability.

    All temporary CSVs and per-run diagnostics live in output/logs.  Only
    fully serialized reports are moved into the user-visible output folder.
    """
    if output_dir is None:
        output_dir = env_dir.parent
    if run_id is None:
        run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    report_at = report_at or datetime.now().astimezone()
    by_topology: dict[str, dict[str, dict]] = defaultdict(dict)
    for key, record in rows.items():
        folder_name = record['row']['system']
        by_topology[folder_name][key] = record

    for folder_name, output_rows in sorted(by_topology.items()):
        target_dir = env_dir / 'process_scheduler' / base / cob / folder_name
        log_dir = _diagnostics_dir(output_dir, environment, cob, folder_name, run_id)
        log_dir.mkdir(parents=True, exist_ok=True)
        job_name = report_filename(environment, cob, folder_name, 'jobs', output_format, created_at=report_at)
        duplicate_name = report_filename(environment, cob, folder_name, 'duplicates', output_format, created_at=report_at)
        target = target_dir / job_name
        duplicates_target = target_dir / duplicate_name
        matching_dups = [(relative, winner, duplicate) for relative, winner, duplicate in duplicates
                         if f'/{folder_name.casefold()}/' in winner.replace('\\', '/').casefold()]
        staged_jobs_csv = log_dir / 'jobs.work.csv'
        staged_duplicates_csv = log_dir / 'duplicates.work.csv'
        staged_jobs_xlsx = log_dir / 'jobs.work.xlsx'
        staged_duplicates_xlsx = log_dir / 'duplicates.work.xlsx'
        status = 'CompletedWithWarnings' if partial else 'Completed'
        latest_path = log_dir.parent / 'latest.json'
        backups: list[Path] = []
        try:
            analyze.atomic_csv(staged_jobs_csv, output_rows, delimiter)
            _atomic_duplicates(staged_duplicates_csv, matching_dups)
            if output_format == 'xlsx':
                excel_export.export_csv_to_xlsx(staged_jobs_csv, staged_jobs_xlsx, delimiter=delimiter)
                excel_export.export_csv_to_xlsx(staged_duplicates_csv, staged_duplicates_xlsx)
                prepared_jobs, prepared_duplicates = staged_jobs_xlsx, staged_duplicates_xlsx
            else:
                prepared_jobs, prepared_duplicates = staged_jobs_csv, staged_duplicates_csv
            previous: dict = {}
            if latest_path.is_file():
                try:
                    previous = json.loads(latest_path.read_text(encoding='utf-8'))
                    if not isinstance(previous, dict):
                        previous = {}
                except (OSError, ValueError):
                    previous = {}

            prior_by_kind: dict[str, list[Path]] = {'jobs': [], 'duplicates': []}
            for field, kind in (('report', 'jobs'), ('duplicates_report', 'duplicates')):
                stored = previous.get(field)
                if isinstance(stored, str):
                    candidate = Path(stored)
                    if candidate.parent.resolve() == target_dir.resolve():
                        prior_by_kind[kind].append(candidate)
            # Exact names used by older versions; never glob/delete user files.
            for kind in ('jobs', 'duplicates'):
                prior_by_kind[kind].extend(
                    target_dir / f'{kind}.{fmt}' for fmt in ('csv', 'xlsx')
                )
                prior_by_kind[kind].extend(
                    target_dir / f'{environment}_{cob}_{folder_name}_{kind}.{fmt}'
                    for fmt in ('csv', 'xlsx')
                )
            prior_reports = [item for sources in prior_by_kind.values() for item in sources]
            if partial:
                if previous.get('status') in (None, 'Completed'):
                    for old_kind, originals in prior_by_kind.items():
                        for original in dict.fromkeys(originals):
                            if original.is_file():
                                backup = log_dir.parent / '_last_complete' / f'{old_kind}{original.suffix}'
                                _atomic_backup(original, backup)
                                backups.append(backup)
                else:
                    # Keep the known-good backup reference across warning-only runs.
                    backups = [Path(item) for item in previous.get('previous_complete_backups', [])
                               if isinstance(item, str)]
            # A failed serialization cannot replace the previous visible workbook.
            target_dir.mkdir(parents=True, exist_ok=True)
            # Publish the primary jobs report last: if that replacement fails,
            # the previously visible jobs report is still intact.
            os.replace(prepared_duplicates, duplicates_target)
            os.replace(prepared_jobs, target)
        except (OSError, ValueError, UnicodeError) as exc:
            _write_diagnostics(
                log_dir, environment=environment, cob=cob, topology=folder_name,
                status='ExportFailed', failures=[*failures, f'EXPORT FAILED: {exc}'],
                report_paths=[], row_count=len(output_rows),
                duplicate_count=len(matching_dups), missing_timestamps=missing_timestamps,
                conflicts=conflicts, host_failures=host_failures,
                file_failures=file_failures, started_at=started_at,
                finished_at=datetime.now(timezone.utc).isoformat(),
            )
            raise
        finally:
            for temporary in (staged_jobs_csv, staged_duplicates_csv,
                              staged_jobs_xlsx, staged_duplicates_xlsx):
                temporary.unlink(missing_ok=True)

        # Publish succeeded: retain only the current generated report pair.
        # Old report names are deleted by exact known paths, never by broad glob.
        for obsolete in dict.fromkeys([*prior_reports,
                                     target_dir / 'jobs.partial.csv',
                                     target_dir / 'jobs.partial.xlsx',
                                     target_dir / 'duplicates.partial.csv',
                                     target_dir / 'duplicates.partial.xlsx',
                                     target_dir / 'issues.partial.txt']):
            if obsolete not in (target, duplicates_target):
                try:
                    obsolete.unlink(missing_ok=True)
                except OSError:
                    pass  # Report was already safely published; next run can retry cleanup.
        _write_diagnostics(
            log_dir, environment=environment, cob=cob, topology=folder_name,
            status=status, failures=failures, report_paths=[target, duplicates_target],
            row_count=len(output_rows), duplicate_count=len(matching_dups),
            missing_timestamps=missing_timestamps, conflicts=conflicts,
            host_failures=host_failures, file_failures=file_failures,
            started_at=started_at, finished_at=datetime.now(timezone.utc).isoformat(),
            previous_complete_backups=backups,
        )
        analyze.atomic_json(latest_path, {
            'status': status, 'run_id': run_id,
            'diagnostics': str(log_dir / 'run.json'),
            'report': str(target), 'duplicates_report': str(duplicates_target),
            'previous_complete_backups': [str(p) for p in backups],
        })
        print(f'REPORT: {target} ({len(output_rows)} logs; {status})', file=stdout)
        print(f'DIAGNOSTICS: {log_dir / "run.json"}', file=stdout)
        if failures:
            print(f'ISSUES: {log_dir / "issues.log"} ({len(failures)} errors)', file=stdout)
    return len(by_topology)


def extract(
    *, config: dict, config_dir: Path, environment: str, topology: str,
    output_dir: Path, encoding: str, delimiter: str = ',', only_date: str | None = None,
    now: datetime | None = None, stdout: TextIO | None = None,
    stderr: TextIO | None = None, progress: ConsoleProgress | None = None,
    output_format: str = 'csv',
) -> int:
    """Return 0 when all sources were scanned, 2 when the run has warnings.

    Both outcomes publish an ordinary named report, with run diagnostics
    and completeness details stored under output/logs.
    """
    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    if output_format not in excel_export.OUTPUT_FORMATS:
        raise ValueError('Unsupported output format')
    _, groups = settings_for(config, environment, config_dir=config_dir)
    target_root = (output_dir / environment).resolve()
    for agents in groups:
        for agent in agents:
            source_root = agent.root.resolve()
            if target_root.is_relative_to(source_root) or source_root.is_relative_to(target_root):
                raise ValueError('Output directory must be separate from all Process Scheduler log shares')
    base, from_name_date, exact_folder = parse_topology(topology)
    if only_date and not analyze.valid_cob(only_date):
        raise ValueError('--date must be a valid YYYYMMDD date')
    if from_name_date and only_date and from_name_date != only_date:
        raise ValueError('Topology folder date conflicts with --date')
    only_date = from_name_date or only_date
    if len(delimiter) != 1 or delimiter in ('\r', '\n', '"'):
        raise ValueError('Invalid CSV delimiter')
    report_at_override = now
    now = now or datetime.now().astimezone()
    policy = analyze.policy_from_config(config)
    error_following_lines = analyze.error_following_lines_from_config(config)
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    started_at = datetime.now(timezone.utc).isoformat()
    agent_cobs, source_failures = _discover_hosts(
        groups, now, only_date, stdout, stderr, progress,
    )
    if not agent_cobs:
        diagnostic = _diagnostics_dir(output_dir, environment, only_date or 'unknown', topology, run_id)
        _write_diagnostics(
            diagnostic, environment=environment, cob=only_date or 'unknown',
            topology=topology, status='Failed', failures=source_failures,
            report_paths=[], row_count=0, duplicate_count=0,
            missing_timestamps=0, conflicts=0,
            host_failures=len(source_failures), file_failures=0,
            started_at=started_at, finished_at=datetime.now(timezone.utc).isoformat(),
        )
        raise ValueError(f'No Process Scheduler hosts accessible; see {diagnostic / "issues.log"}')
    eligible = sorted({cob for _, dates in agent_cobs for cob in dates}, reverse=True)
    selected = eligible if only_date else eligible[:policy.cob_scan_limit]
    selected.reverse()
    if not selected:
        diagnostic = _diagnostics_dir(output_dir, environment, only_date or 'unknown', topology, run_id)
        detail = 'No eligible COB folders found across accessible hosts'
        _write_diagnostics(
            diagnostic, environment=environment, cob=only_date or 'unknown',
            topology=topology, status='Failed', failures=[*source_failures, detail],
            report_paths=[], row_count=0, duplicate_count=0,
            missing_timestamps=0, conflicts=0,
            host_failures=len(source_failures), file_failures=0,
            started_at=started_at, finished_at=datetime.now(timezone.utc).isoformat(),
        )
        raise ValueError(f'{detail}; see {diagnostic / "issues.log"}')
    if progress:
        progress.discovered(len(selected))
    reports = duplicates_total = parsed_total = conflict_total = failed_total = 0
    found_topology = False
    safe_base = base  # Validated as one path component by parse_topology.
    env_dir = output_dir / environment
    with analyze.environment_lock(env_dir):
        for position, cob in enumerate(selected, 1):
            if progress:
                progress.begin_cob(cob, position)
            # Filename collisions with distinct payloads remain separate CSV rows.
            logical, cob_failures = _collect_cob_logs(
                cob, agent_cobs, safe_base, exact_folder,
            )
            if not logical:
                if progress:
                    progress.set_file_total(0)
                    progress.end_cob()
                continue
            found_topology = True
            extraction = _enrich_cob_logs(
                logical, encoding=encoding, now=now,
                recent_minutes=policy.recent_minutes, workers=policy.read_workers,
                progress=progress,
                error_following_lines=error_following_lines,
            )
            rows, duplicates = extraction.rows, extraction.duplicates
            conflicts, missing_timestamps = extraction.conflicts, extraction.missing_timestamps
            cob_failures.extend(extraction.failures)
            if conflicts:
                print(f'WARN: COB {cob}: {conflicts} filename collisions have DIFFERENT contents; all retained', file=stderr)
            if missing_timestamps:
                print(f'WARN: COB {cob}: {missing_timestamps} logs have no parseable timestamps', file=stderr)
            _print_cob_failures(cob, cob_failures, stderr)
            if not rows:
                # Never replace an existing usable report with an empty export
                # when all discovered log files were unreadable.
                diagnostic = _diagnostics_dir(output_dir, environment, cob,
                                              exact_folder or safe_base, run_id)
                _write_diagnostics(
                    diagnostic, environment=environment, cob=cob,
                    topology=exact_folder or safe_base, status='Failed',
                    failures=[*source_failures, *cob_failures,
                              'No log files could be parsed for this COB'],
                    report_paths=[], row_count=0, duplicate_count=len(duplicates),
                    missing_timestamps=missing_timestamps, conflicts=conflicts,
                    host_failures=len(source_failures), file_failures=len(cob_failures),
                    started_at=started_at, finished_at=datetime.now(timezone.utc).isoformat(),
                )
                print(f'WARN: No readable logs for COB {cob}; see {diagnostic / "issues.log"}',
                      file=stderr)
                failed_total += len(cob_failures)
                continue
            partial = bool(source_failures or cob_failures)
            published = _publish_cob_reports(
                env_dir=env_dir, base=safe_base, cob=cob, rows=rows,
                duplicates=duplicates, partial=partial,
                failures=[*source_failures, *cob_failures], delimiter=delimiter,
                stdout=stdout, output_format=output_format,
                environment=environment, output_dir=output_dir,
                run_id=run_id, started_at=started_at, report_at=report_at_override,
                missing_timestamps=missing_timestamps, conflicts=conflicts,
                host_failures=len(source_failures), file_failures=len(cob_failures),
            )
            reports += published
            if progress:
                progress.end_cob(written=bool(published))
            parsed_total += len(rows)
            duplicates_total += len(duplicates)
            conflict_total += conflicts
            failed_total += len(cob_failures)
    if not found_topology:
        diagnostic = _diagnostics_dir(output_dir, environment, only_date or 'unknown',
                                      topology, run_id)
        message = f'No .log files found for topology {topology!r} in selected COBs'
        _write_diagnostics(
            diagnostic, environment=environment, cob=only_date or 'unknown',
            topology=topology, status='Failed', failures=[*source_failures, message],
            report_paths=[], row_count=0, duplicate_count=0,
            missing_timestamps=0, conflicts=0,
            host_failures=len(source_failures), file_failures=failed_total,
            started_at=started_at, finished_at=datetime.now(timezone.utc).isoformat(),
        )
        raise ValueError(f'{message}; see {diagnostic / "issues.log"}')
    print(f'Process Scheduler: env={environment}; topology={topology}; '
          f'logs={parsed_total}; duplicate copies={duplicates_total}; '
          f'content conflicts={conflict_total}; host errors={len(source_failures)}; '
          f'file/directory errors={failed_total}; reports={reports}', file=stdout)
    if not reports:
        raise ValueError('No readable logs; no report published. See output/logs diagnostics.')
    if source_failures or failed_total:
        print(f'COMPLETED WITH WARNINGS: {len(source_failures)} inaccessible host(s), '
              f'{failed_total} failed file/directory operation(s). '
              'See output/logs/<ENV>/<COB>/<TOPOLOGY>/<RUN>/issues.log; '
              'log ERROR records and missing timestamps do not trigger this warning.', file=stderr)
    return 2 if source_failures or failed_total else 0
