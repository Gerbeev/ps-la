"""Dependency-free streaming Excel report export with bounded, fixed-height rows.

The CSV remains the canonical input, so the log parsers and their incremental
state do not depend on an Excel-specific library being available on bank PCs.
"""
from __future__ import annotations

import csv
import os
from pathlib import Path
import shutil
import sys
import tempfile
from xml.sax.saxutils import escape
from zipfile import ZIP_DEFLATED, ZipFile

OUTPUT_FORMATS = frozenset({'csv', 'xlsx'})
MAX_XLSX_ROWS = 1_048_576
MAX_CELL_CHARS = 32_767

COLUMN_WIDTHS = {
    'job_date': 13, 'system': 29, 'job_name': 53, 'job_status': 17,
    'last_modified_time': 24, 'start_time': 24, 'end_time': 24,
    'duration': 15, 'restart_count': 14, 'warning_count': 15,
    'error_count': 14, 'last_error': 68, 'file_size_bytes': 18,
    'enrichment_status': 21, 'enriched_at_utc': 25,
    'activity_status': 24, 'host': 31, 'path': 70,
    'relative_log_path': 62, 'retained_source': 70, 'duplicate_source': 70,
}


def validate_format(config: dict) -> str:
    value = config.get('output_format', 'csv')
    if not isinstance(value, str) or value.lower() not in OUTPUT_FORMATS:
        raise ValueError("output_format must be 'csv' or 'xlsx'")
    return value.lower()


def _xml_text(text: str) -> str:
    # XML 1.0 does not admit control characters. Excel limits cell length.
    clean = ''.join(ch for ch in text if ch in '\t\n\r' or 32 <= ord(ch) <= 0xD7FF
                    or 0xE000 <= ord(ch) <= 0xFFFD or 0x10000 <= ord(ch) <= 0x10FFFF)
    return escape(clean[:MAX_CELL_CHARS], {'"': '&quot;'})


def _column_name(position: int) -> str:
    chars = ''
    while position:
        position, digit = divmod(position - 1, 26)
        chars = chr(65 + digit) + chars
    return chars


def export_csv_to_xlsx(csv_path: Path, destination: Path, *, delimiter: str = ',') -> None:
    """Write one readable sheet without reading the whole report into RAM.

    Atomic replace means a bad CSV/failed export cannot corrupt the previous
    complete workbook. All cells are literal strings (never executable formulas).
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix='.xlsx-',
                                         suffix='.tmp', delete=False) as stream:
            temp = Path(stream.name)
        csv.field_size_limit(sys.maxsize)
        with csv_path.open('r', encoding='utf-8-sig', newline='') as source, \
                ZipFile(temp, 'w', compression=ZIP_DEFLATED, compresslevel=5,
                        allowZip64=True) as workbook:
            reader = csv.reader(source, delimiter=delimiter)
            headers = next(reader, None)
            if not headers:
                raise ValueError(f'Cannot export empty CSV: {csv_path}')
            if len(headers) > 16_384:
                raise ValueError('Excel supports no more than 16384 columns')
            end = _column_name(len(headers))
            workbook.writestr('[Content_Types].xml', CONTENT_TYPES)
            workbook.writestr('_rels/.rels', ROOT_RELS)
            workbook.writestr('xl/workbook.xml', WORKBOOK)
            workbook.writestr('xl/_rels/workbook.xml.rels', WORKBOOK_RELS)
            workbook.writestr('xl/styles.xml', STYLES)
            with workbook.open('xl/worksheets/sheet1.xml', 'w') as target:
                def write(data: str) -> None:
                    target.write(data.encode('utf-8'))
                write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                      '<sheetViews><sheetView workbookViewId="0">'
                      '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
                      '</sheetView></sheetViews><sheetFormatPr defaultRowHeight="19"/>')
                write('<cols>')
                for col, name in enumerate(headers, 1):
                    width = COLUMN_WIDTHS.get(name, min(42, max(14, len(name) + 4)))
                    write(f'<col min="{col}" max="{col}" width="{width}" customWidth="1"/>')
                write('</cols><sheetData>')
                count = 0
                for count, cells in enumerate(_include_header(headers, reader), 1):
                    if count > MAX_XLSX_ROWS:
                        raise ValueError(f'Excel limit exceeded: {MAX_XLSX_ROWS} rows')
                    if len(cells) != len(headers):
                        raise ValueError(f'CSV row {count} has {len(cells)} cells, expected {len(headers)}')
                    # Fixed row heights keep multi-line ERROR messages compact.
                    style = 1 if count == 1 else (3 if count % 2 == 0 else 2)
                    height = 26 if count == 1 else 19
                    write(f'<row r="{count}" ht="{height}" customHeight="1">')
                    for col, value in enumerate(cells, 1):
                        ref = f'{_column_name(col)}{count}'
                        write(f'<c r="{ref}" s="{style}" t="inlineStr">'
                              f'<is><t xml:space="preserve">{_xml_text(value)}</t></is></c>')
                    write('</row>')
                write(f'</sheetData><autoFilter ref="A1:{end}{count}"/>')
                write('</worksheet>')
        os.replace(temp, destination)
        temp = None
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


def _include_header(headers: list[str], reader: csv.reader):
    yield headers
    yield from reader


def _atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix='.csv-copy-',
                                         suffix='.tmp', delete=False) as sink:
            temporary = Path(sink.name)
            with source.open('rb') as stream:
                shutil.copyfileobj(stream, sink)
            sink.flush()
            os.fsync(sink.fileno())
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def ordinary_csv_storage(env_dir: Path, cob: str, output_format: str) -> Path:
    """Preserve CSV for incremental/finalized COBs outside Excel output folders.

    Supports changing CSV <-> Excel without rereading archived log contents.
    """
    visible = env_dir / cob / 'jobs.csv'
    cached = env_dir / '.state' / 'report_csv' / f'{cob}.csv'
    if output_format == 'xlsx':
        if visible.is_file():
            # CSV may have changed since the last XLSX run; it is authoritative
            # whenever present after switching the setting back from CSV.
            cached.parent.mkdir(parents=True, exist_ok=True)
            _atomic_copy(visible, cached)
        return cached
    if not visible.exists() and cached.is_file():
        visible.parent.mkdir(parents=True, exist_ok=True)
        _atomic_copy(cached, visible)
    return visible


CONTENT_TYPES = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>'''
ROOT_RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>'''
WORKBOOK = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Jobs" sheetId="1" r:id="rId1"/></sheets></workbook>'''
WORKBOOK_RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>'''
STYLES = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="10"/><name val="Aptos"/><color rgb="FF263348"/></font><font><b/><sz val="10"/><name val="Aptos"/><color rgb="FFFFFFFF"/></font></fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF17365D"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF1F5FA"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center" horizontal="left"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf></cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>'''
