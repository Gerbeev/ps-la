"""Regression tests for multi-line errors and Process Scheduler partial reports."""
from __future__ import annotations

import csv
import sys
import unittest
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import analyze
import process_scheduler


class MultiLineErrorTests(unittest.TestCase):
    def setUp(self) -> None:
        tmp = TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.log = self.root / 'job.log'

    def parse(self, content: str) -> analyze.FileSummary:
        self.log.write_text(content, encoding='utf-8')
        return analyze.analyze_log(self.log, '20261007')

    def test_stack_trace_captured_until_next_record(self) -> None:
        summary = self.parse(
            '2026-10-08 10:00:00,111 [1] INFO : Start\n'
            '2026-10-08 10:01:00,222 [2] ERROR : Transformation failed\n'
            'System.InvalidOperationException: inner issue\n'
            '   at Service.Run() in C:\\work\\Service.cs:line 33\n'
            '\n'
            'Caused by: timeout\n'
            '2026-10-08 10:02:00,000 [1] INFO : Next task\n'
            'later non-timestamp continuation unrelated to error\n'
        )
        self.assertEqual(summary.error_count, 1)
        self.assertEqual(summary.last_error,
            '2026-10-08 10:01:00,222 [2] ERROR : Transformation failed\n'
            'System.InvalidOperationException: inner issue\n'
            '   at Service.Run() in C:\\work\\Service.cs:line 33\n'
            '\nCaused by: timeout')
        self.assertEqual(summary.end_time, '2026-10-08 10:02:00.000')

    def test_last_error_continues_to_eof_without_next_timestamp(self) -> None:
        summary = self.parse(
            '2026-10-08 10:00:00 [1] ERROR : Failure\n'
            'Nested failure\n'
            '  at step1\n'
            '  at step2'
        )
        self.assertEqual(summary.last_error,
                         '2026-10-08 10:00:00 [1] ERROR : Failure\n'
                         'Nested failure\n  at step1\n  at step2')

    def test_new_error_overwrites_prior_block_without_changing_error_count(self) -> None:
        summary = self.parse(
            '2026-10-08 10:00:00 [1] ERROR : First\n  old detail\n'
            '2026-10-08 10:01:00 [1] WARN : Warning\n  warning continuation\n'
            '2026-10-08 10:02:00 [1] ERROR : Last\n  final detail\n'
        )
        self.assertEqual(summary.error_count, 2)
        self.assertEqual(summary.warning_count, 1)
        self.assertEqual(summary.last_error,
                         '2026-10-08 10:02:00 [1] ERROR : Last\n  final detail')

    def test_unknown_level_timestamp_stops_error_block(self) -> None:
        summary = self.parse(
            '2026-10-08 10:00:00 [1] ERROR : First\ntrace detail\n'
            '2026/10/08 10:03:00 [1] NOTICE : another event\n'
            'not part of error\n'
        )
        self.assertEqual(summary.last_error,
                         '2026-10-08 10:00:00 [1] ERROR : First\ntrace detail')

    def test_incremental_append_continues_error_before_timestamp_boundary(self) -> None:
        first = '2026-10-08 10:00:00 [1] ERROR : Broken\n  stack row 1\n'
        self.log.write_text(first, encoding='utf-8')
        first_state: dict = {}
        with analyze.open_shared_log(self.log) as stream:
            analyze._analyze_stream(stream, self.log, '20261007', 'utf-8-sig', '', None,
                                    False, checkpoint=first_state)
        self.assertTrue(first_state['error_open'])
        with self.log.open('a', encoding='utf-8') as stream:
            stream.write('  stack row 2\n2026-10-08 10:01:00 [1] INFO : done\n')
        with analyze.open_shared_log(self.log) as stream:
            summary, checkpoint, _ = analyze._scan_from(
                stream, start_offset=first_state['offset'],
                limit=self.log.stat().st_size, encoding='utf-8-sig',
                initial=first_state, include_tail=False,
                file_path=self.log, job_date='20261007', system='')
        self.assertEqual(summary.last_error, '2026-10-08 10:00:00 [1] ERROR : Broken\n'
                                                  '  stack row 1\n  stack row 2')
        self.assertFalse(checkpoint['error_open'])

    def test_incomplete_tail_is_not_saved_as_complete_error_continuation(self) -> None:
        self.log.write_text('2026-10-08 10:00:00 [1] ERROR : E\n  complete\n  unfinished',
                            encoding='utf-8')
        with analyze.open_shared_log(self.log) as stream:
            summary, state, _ = analyze._scan_from(
                stream, start_offset=0, limit=self.log.stat().st_size,
                encoding='utf-8-sig', initial=analyze._new_accumulator(),
                include_tail=False, file_path=self.log, job_date='20261007', system='')
        self.assertTrue(summary.last_error.endswith('  complete'))
        self.assertNotIn('unfinished', summary.last_error)
        self.assertTrue(state['error_open'])
        with self.log.open('a', encoding='utf-8') as stream:
            stream.write(' detail\n')
        with analyze.open_shared_log(self.log) as stream:
            summary, _, _ = analyze._scan_from(
                stream, start_offset=state['offset'], limit=self.log.stat().st_size,
                encoding='utf-8-sig', initial=state,
                include_tail=False, file_path=self.log, job_date='20261007', system='')
        self.assertTrue(summary.last_error.endswith('  unfinished detail'))

    def test_csv_preserves_newlines_in_one_field(self) -> None:
        error = '2026-10-08 10:00:00 [1] ERROR : Fail\nSystem.Exception\n  at Main()'
        summary = self.parse(error + '\n')
        row = analyze.enriched_row(summary, [self.log.stat().st_size,
                                             self.log.stat().st_mtime_ns,
                                             self.log.stat().st_ctime_ns],
                                   str(self.log), now=datetime(2026, 10, 9, tzinfo=timezone.utc),
                                   recent_minutes=5)
        output = self.root / 'jobs.csv'
        analyze.atomic_csv(output, {'a': {'row': row}}, ',')
        with output.open(encoding='utf-8-sig', newline='') as stream:
            parsed = list(csv.DictReader(stream))
        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0]['last_error'], error)

    def test_process_scheduler_does_not_mark_job_errors_as_partial(self) -> None:
        share = self.root / 'agent'
        folder = 'DataPlatform_20261007_Thursday'
        target = share / '20261007' / folder / 'broken.log'
        target.parent.mkdir(parents=True)
        target.write_text('2026-10-08 10:00:00 [1] ERROR : failed\n'
                          'Exception text\ntrace row\n', encoding='utf-8')
        config = {'incremental': {'read_workers': 1}, 'environments': {
            'U5': {'logs_root': 'unused', 'process_scheduler': {
                'share': 'RALogs', 'default_topology': 'DataPlatform',
                'hosts': [{'name': 'agent.example.org', 'root': str(share)}],
                'host_aliases': {},
            }}
        }}
        result = process_scheduler.extract(
            config=config, config_dir=self.root, environment='U5', topology=folder,
            output_dir=self.root / 'output', encoding='utf-8-sig',
            now=datetime(2026, 10, 8, 12, tzinfo=timezone.utc),
            stdout=StringIO(), stderr=StringIO(),
        )
        self.assertEqual(result, 0)
        output = self.root / 'output/U5/process_scheduler/DataPlatform/20261007' / folder
        self.assertTrue((output / 'jobs.csv').exists())
        self.assertFalse((output / 'jobs.partial.csv').exists())
        with (output / 'jobs.csv').open(encoding='utf-8-sig', newline='') as stream:
            self.assertEqual(next(csv.DictReader(stream))['last_error'],
                             '2026-10-08 10:00:00 [1] ERROR : failed\nException text\ntrace row')

    def test_unparseable_timestamps_do_not_cause_partial(self) -> None:
        share = self.root / 'agent'
        folder = 'DataPlatform_20261007_Thursday'
        source = share / '20261007' / folder / 'no_timestamp.log'
        source.parent.mkdir(parents=True)
        source.write_text('No timestamp on either line\nStill no timestamp\n', encoding='utf-8')
        config = {'environments': {'U5': {'logs_root': 'unused', 'process_scheduler': {
            'share': 'RALogs', 'default_topology': 'DataPlatform',
            'hosts': [{'name': 'agent.example.org', 'root': str(share)}],
            'host_aliases': {},
        }}}}
        stdout, stderr = StringIO(), StringIO()
        status = process_scheduler.extract(
            config=config, config_dir=self.root, environment='U5', topology=folder,
            output_dir=self.root / 'out', encoding='utf-8-sig',
            now=datetime(2026, 10, 8, 12, tzinfo=timezone.utc),
            stdout=stdout, stderr=stderr,
        )
        self.assertEqual(status, 0)
        self.assertIn('1 logs have no parseable timestamps', stderr.getvalue())
        self.assertIn('file/directory errors=0', stdout.getvalue())
        self.assertTrue((self.root / 'out/U5/process_scheduler/DataPlatform/20261007' /
                         folder / 'jobs.csv').exists())


if __name__ == '__main__':
    unittest.main()
