"""Timestamp-free logs remain present and distinguishable in CSV exports."""
from __future__ import annotations

import csv
import json
import os
import sys
import unittest
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import analyze
import process_scheduler


NOW = datetime(2026, 10, 8, 12, tzinfo=timezone.utc)
COB = "20261007"
TOPOLOGY = "DataPlatform_20261007_Thursday"


def read_rows(path: Path) -> dict[str, dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return {row["job_name"]: row for row in csv.DictReader(stream)}


class ProcessSchedulerNoTimestampTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.share = self.root / "host"
        self.folder = self.share / COB / TOPOLOGY
        self.folder.mkdir(parents=True)
        self.config = {"environments": {"U5": {"process_scheduler": {
            "share": "RALogs", "default_topology": "DataPlatform",
            "hosts": [{"name": "host.example.net", "root": str(self.share)}],
        }}}}
        self.output = (self.root / "output" / "U5" / "process_scheduler" /
                       "DataPlatform" / COB / TOPOLOGY)

    def run_extraction(self) -> tuple[int, str, str]:
        stdout, stderr = StringIO(), StringIO()
        exit_code = process_scheduler.extract(
            config=self.config, config_dir=self.root,
            environment="U5", topology=TOPOLOGY,
            output_dir=self.root / "output", encoding="utf-8-sig",
            now=NOW, stdout=stdout, stderr=stderr,
        )
        return exit_code, stdout.getvalue(), stderr.getvalue()

    def test_no_timestamp_empty_and_regular_logs_are_all_in_complete_csv(self) -> None:
        (self.folder / "plain.log").write_text("no date\nexception details\n", encoding="utf-8")
        (self.folder / "empty.log").write_bytes(b"")
        (self.folder / "dated.log").write_text(
            "2026-10-08 08:00:00,000 [1] INFO : Started\n", encoding="utf-8")
        result, stdout, stderr = self.run_extraction()
        self.assertEqual(result, 0)
        self.assertTrue((self.output / "jobs.csv").exists())
        self.assertFalse((self.output / "jobs.partial.csv").exists())
        self.assertIn("2 logs have no parseable timestamps", stderr)
        self.assertIn("file/directory errors=0", stdout)
        rows = read_rows(self.output / "jobs.csv")
        self.assertEqual(set(rows), {"plain", "empty", "dated"})
        for name in ("plain", "empty"):
            row = rows[name]
            self.assertEqual(row["enrichment_status"], "NoTimestamps")
            self.assertEqual(row["job_status"], "Unknown")
            self.assertEqual(row["start_time"], "")
            self.assertEqual(row["end_time"], "")
            self.assertEqual(row["duration"], "")
            self.assertEqual(row["warning_count"], "0")
            self.assertEqual(row["error_count"], "0")
            self.assertTrue(row["enriched_at_utc"])
            self.assertTrue(row["path"].endswith(name + ".log"))
        self.assertEqual(rows["plain"]["file_size_bytes"], str(len(b"no date\nexception details\n")))
        self.assertEqual(rows["empty"]["file_size_bytes"], "0")
        self.assertEqual(rows["dated"]["enrichment_status"], "Enriched")
        self.assertEqual(rows["dated"]["job_status"], "Completed")

    def test_duplicate_copies_without_timestamps_are_retained_once(self) -> None:
        second_share = self.root / "second"
        second_folder = second_share / COB / TOPOLOGY
        second_folder.mkdir(parents=True)
        for folder in (self.folder, second_folder):
            (folder / "plain.log").write_text("text without date\n", encoding="utf-8")
        self.config["environments"]["U5"]["process_scheduler"]["hosts"].append(
            {"name": "other.example.net", "root": str(second_share)})
        status, stdout, _ = self.run_extraction()
        self.assertEqual(status, 0)
        self.assertEqual(len(read_rows(self.output / "jobs.csv")), 1)
        self.assertEqual(read_rows(self.output / "jobs.csv")["plain"]["enrichment_status"],
                         "NoTimestamps")
        self.assertIn("duplicate copies=1", stdout)
        with (self.output / "duplicates.csv").open(encoding="utf-8-sig", newline="") as stream:
            self.assertEqual(len(list(csv.DictReader(stream))), 1)

    def test_no_timestamp_row_is_in_partial_report_when_another_host_fails(self) -> None:
        (self.folder / "plain.log").write_text("no date\n", encoding="utf-8")
        self.config["environments"]["U5"]["process_scheduler"]["hosts"].append(
            {"name": "unavailable.example.net", "root": str(self.root / "missing-host")})
        status, stdout, stderr = self.run_extraction()
        self.assertEqual(status, 2)
        self.assertIn("host errors=1", stdout)
        self.assertIn("1 logs have no parseable timestamps", stderr)
        self.assertFalse((self.output / "jobs.csv").exists())
        self.assertEqual(read_rows(self.output / "jobs.partial.csv")["plain"]["enrichment_status"],
                         "NoTimestamps")
        self.assertTrue((self.output / "issues.partial.txt").exists())


class IncrementalNoTimestampTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.log = self.root / "Logs" / COB / "Jobs" / "plain.log"
        self.log.parent.mkdir(parents=True)
        self.log.write_text("no timestamp on this line\n", encoding="utf-8")
        os.utime(self.log, (NOW.timestamp() - 60, NOW.timestamp() - 60))
        self.output = self.root / "output"
        self.report = self.output / "PROD" / COB / "jobs.csv"
        self.state = self.output / "PROD" / ".state" / f"{COB}.json"

    def run_scan(self, mode: str) -> tuple[tuple, str]:
        stdout, stderr = StringIO(), StringIO()
        result = analyze.write_csv(
            root=self.root / "Logs", output_dir=self.output,
            environment="PROD", encoding="utf-8-sig", delimiter=",",
            only_date=COB, policy=analyze.IncrementalPolicy(7, 72),
            now=NOW, force=False, stdout=stdout, stderr=stderr, mode=mode,
        )
        return result, stderr.getvalue()

    def test_pending_to_no_timestamps_then_append_to_enriched(self) -> None:
        self.run_scan("inventory")
        self.assertEqual(read_rows(self.report)["plain"]["enrichment_status"], "Pending")
        self.run_scan("enrich")
        self.assertEqual(read_rows(self.report)["plain"]["enrichment_status"], "NoTimestamps")
        self.assertEqual(read_rows(self.report)["plain"]["job_status"], "Unknown")
        self.assertEqual(read_rows(self.report)["plain"]["start_time"], "")
        before = self.report.read_bytes()
        with patch.object(analyze, "parse_changed", side_effect=AssertionError("unexpected reparse")):
            self.run_scan("enrich")
        self.assertEqual(self.report.read_bytes(), before)

        with self.log.open("a", encoding="utf-8") as handle:
            handle.write("2026-10-08 12:00:00,000 [1] INFO : Started\n")
        os.utime(self.log, (NOW.timestamp(), NOW.timestamp()))
        self.run_scan("enrich")
        self.assertEqual(read_rows(self.report)["plain"]["enrichment_status"], "Enriched")
        self.assertEqual(read_rows(self.report)["plain"]["start_time"], "2026-10-08 12:00:00.000")

    def test_old_enriched_no_timestamp_cache_migrates_without_log_read(self) -> None:
        self.run_scan("enrich")
        stored = json.loads(self.state.read_text(encoding="utf-8"))
        row = next(iter(stored["files"].values()))["row"]
        row["enrichment_status"] = "Enriched"
        row["job_status"] = "Completed"
        self.state.write_text(json.dumps(stored), encoding="utf-8")
        with patch.object(analyze, "parse_changed", side_effect=AssertionError("unexpected reparse")):
            self.run_scan("enrich")
        refreshed = read_rows(self.report)["plain"]
        self.assertEqual(refreshed["enrichment_status"], "NoTimestamps")
        self.assertEqual(refreshed["job_status"], "Unknown")

    def test_inventory_keeps_no_timestamps_when_metadata_unchanged(self) -> None:
        self.run_scan("enrich")
        self.run_scan("inventory")
        self.assertEqual(read_rows(self.report)["plain"]["enrichment_status"], "NoTimestamps")


if __name__ == "__main__":
    unittest.main()