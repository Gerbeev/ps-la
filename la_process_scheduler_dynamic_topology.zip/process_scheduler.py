#!/usr/bin/env python3
"""Read-only Process Scheduler host fan-out, content deduplication and CSV export.

Requires Python 3.11+, stdlib only. Does not call the scheduler's internal API:
its topology URL documents the topology, while configured agents supply UNC roots.
"""
from __future__ import annotations

from collections import defaultdict, deque
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from hashlib import sha256
import csv
import os
from pathlib import Path
import re
import sys
from typing import TextIO
from urllib.parse import urlsplit

import analyze
from atomic_io import atomic_text_writer
from progress import ConsoleProgress

HOST_NAME = re.compile(r"^[a-zA-Z0-9](?:[a-zA-Z0-9.-]{0,251}[a-zA-Z0-9])?$")
TOPOLOGY_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$")
FULL_TOPOLOGY = re.compile(r"^(?P<base>.+)_(?P<cob>\d{8})_(?P<suffix>[A-Za-z][A-Za-z0-9_-]*)$")
ENGLISH_WEEKDAYS = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')


@dataclass(frozen=True)
class Agent:
    host: str
    root: Path
    canonical: str


@dataclass(frozen=True)
class SourceLog:
    cob: str
    topology: str
    relative: str
    host: str
    path: Path
    stat: os.stat_result


@dataclass
class SourceResult:
    rows: list[dict]
    duplicates: list[tuple[str, str, str]]
    failures: list[str]
    conflicts: int = 0
    missing_timestamps: int = 0


def configured_environments(config: dict) -> list[str]:
    return [env for env in analyze.ALLOWED_ENVIRONMENTS
            if env in config.get('environments', {})
            and isinstance(config['environments'][env].get('process_scheduler'), dict)]


def settings_for(config: dict, environment: str, *, config_dir: Path) -> tuple[dict, list[list[Agent]]]:
    entry = config['environments'].get(environment, {})
    settings = entry.get('process_scheduler')
    if not isinstance(settings, dict):
        raise ValueError(f'{environment}: process_scheduler is not configured')
    share = settings.get('share')
    if not isinstance(share, str) or not re.fullmatch(r'[A-Za-z0-9_$-]{1,80}', share):
        raise ValueError(f'{environment}: invalid process_scheduler.share')
    url = settings.get('topology_url', '')
    if not isinstance(url, str) or (url and
            (urlsplit(url).scheme != 'https' or not urlsplit(url).hostname or urlsplit(url).username)):
        raise ValueError(f'{environment}: topology_url must be an HTTPS URL')
    default_topology = settings.get('default_topology', '')
    if not isinstance(default_topology, str) or (default_topology and not TOPOLOGY_NAME.fullmatch(default_topology)):
        raise ValueError(f'{environment}: invalid default_topology')
    hosts = settings.get('hosts')
    if not isinstance(hosts, list) or not hosts:
        raise ValueError(f'{environment}: process_scheduler.hosts must be a non-empty list')
    aliases = settings.get('host_aliases', {})
    if not isinstance(aliases, dict) or any(not isinstance(k, str) or not isinstance(v, str)
            or not HOST_NAME.fullmatch(k) or not HOST_NAME.fullmatch(v) for k, v in aliases.items()):
        raise ValueError(f'{environment}: invalid host_aliases dictionary')
    aliases = {k.lower(): v.lower() for k, v in aliases.items()}
    unique_names: set[str] = set()
    groups: dict[str, list[Agent]] = {}
    for host_entry in hosts:
        if not isinstance(host_entry, dict):
            raise ValueError(f'{environment}: host entries must be objects')
        name = host_entry.get('name')
        if not isinstance(name, str) or not HOST_NAME.fullmatch(name):
            raise ValueError(f'{environment}: invalid agent hostname {name!r}')
        name = name.lower()
        if name in unique_names:
            raise ValueError(f'{environment}: duplicate configured hostname: {name}')
        unique_names.add(name)
        enabled = host_entry.get('enabled', True)
        if type(enabled) is not bool:
            raise ValueError(f'{environment}: host.enabled must be boolean')
        root_override = host_entry.get('root')
        if root_override is not None and (not isinstance(root_override, str) or not root_override.strip()):
            raise ValueError(f'{environment}: host.root must be non-empty if supplied')
        if not enabled:
            continue
        if root_override:
            root = Path(os.path.expandvars(os.path.expanduser(root_override)))
            if not root.is_absolute():
                root = config_dir / root
        else:
            root = Path(f'\\\\{name}\\{share}')
        canonical = aliases.get(name, name)
        # Explicit aliases are tried as failover sources for one physical share.
        groups.setdefault(canonical, []).append(Agent(name, root, canonical))
    if not groups:
        raise ValueError(f'{environment}: no enabled Process Scheduler agents')
    return settings, list(groups.values())


def validate_settings(config: dict) -> None:
    for environment in configured_environments(config):
        settings_for(config, environment, config_dir=Path('.'))


def parse_topology(value: str) -> tuple[str, str | None, str | None]:
    value = value.strip()
    if not TOPOLOGY_NAME.fullmatch(value):
        raise ValueError('Topology must contain only letters, digits, underscore or dash (no path or URL)')
    full = FULL_TOPOLOGY.fullmatch(value)
    if full and analyze.valid_cob(full['cob']):
        return full['base'], full['cob'], value
    return value, None, None


def default_topology_name(base: str, *, current_day: date | None = None) -> str:
    """Build the daily topology: yesterday's COB + today's English weekday.

    Use the computer's local date, not the locale-dependent %A formatter.
    For Thursday 2026-10-08 this yields DataPlatform_20261007_Thursday.
    """
    if not isinstance(base, str) or not TOPOLOGY_NAME.fullmatch(base):
        raise ValueError('Process Scheduler default_topology must be a valid base name')
    current_day = current_day if current_day is not None else date.today()
    cob = (current_day - timedelta(days=1)).strftime('%Y%m%d')
    full_name = f'{base}_{cob}_{ENGLISH_WEEKDAYS[current_day.weekday()]}'
    if parse_topology(full_name)[2] != full_name:
        raise ValueError('Generated topology name is invalid')
    return full_name


def _scandir_directories(directory: Path) -> list[str]:
    names = []
    with os.scandir(directory) as iterator:
        for item in iterator:
            if not item.is_symlink() and item.is_dir(follow_symlinks=False):
                names.append(item.name)
    return sorted(names)


def _discover_agent_cobs(agent: Agent, now: datetime, only_date: str | None) -> dict[str, Path]:
    names = _scandir_directories(agent.root)
    today = now.strftime('%Y%m%d')
    return {name: agent.root / name for name in names
            if analyze.valid_cob(name) and name <= today and (not only_date or only_date == name)}


def _hash_log(log: SourceLog) -> bytes:
    """Only hash same-sized filename collisions. Reject source changes while hashing."""
    digest = sha256()
    with analyze.open_shared_log(log.path) as stream:
        before = os.fstat(stream.fileno())
        if analyze.file_signature(before) != analyze.file_signature(log.stat):
            raise OSError('source changed since enumeration')
        while data := stream.read(256 * 1024):
            digest.update(data)
        after = os.fstat(stream.fileno())
        if analyze.file_signature(before) != analyze.file_signature(after):
            raise OSError('source changed while hashing')
    if analyze.file_signature(log.path.stat()) != analyze.file_signature(before):
        raise OSError('source replaced after hashing')
    return digest.digest()


def _process_group(copies: list[SourceLog], encoding: str, now: datetime, recent_minutes: int) -> SourceResult:
    output = SourceResult([], [], [])
    by_size: dict[int, list[SourceLog]] = defaultdict(list)
    for copy in copies:
        by_size[copy.stat.st_size].append(copy)
    candidates: list[tuple[SourceLog, bytes | None]] = []
    for size, subset in by_size.items():
        for copy in subset:
            if len(subset) == 1:
                candidates.append((copy, None))
                continue
            try:
                candidates.append((copy, _hash_log(copy)))
            except (OSError, UnicodeError, ValueError) as exc:
                output.failures.append(f'SKIP: {copy.path}: hashing failed: {exc}')
    # Preserve configured agent priority, independent of grouping by size.
    order = {str(log.path): i for i, log in enumerate(copies)}
    candidates.sort(key=lambda item: order[str(item[0].path)])
    identities: dict[tuple[int, bytes | None], list[SourceLog]] = defaultdict(list)
    for copy, digest in candidates:
        identities[(copy.stat.st_size, digest)].append(copy)
    for same_content in identities.values():
        winner: SourceLog | None = None
        for copy in same_content:
            try:
                parsed = analyze.stable_summary(
                    copy.path, copy.cob, copy.topology, encoding,
                    now=now, recent_minutes=recent_minutes,
                )
                if parsed is None:
                    raise OSError('source changed while parsing')
                if analyze.file_signature(copy.stat) != parsed.signature:
                    raise OSError('source changed after discovery')
                row = analyze.enriched_row(
                    parsed.summary, parsed.signature, str(copy.path),
                    now=now, recent_minutes=recent_minutes,
                )
                if not parsed.summary.start_time or not parsed.summary.end_time:
                    output.missing_timestamps += 1
                output.rows.append(row)
                winner = copy
                break
            except (OSError, UnicodeError, ValueError) as exc:
                output.failures.append(f'SKIP: {copy.path}: parsing failed: {exc}')
        if winner is not None:
            for copy in same_content:
                if copy is winner:
                    continue
                try:
                    if analyze.file_signature(copy.path.stat()) != analyze.file_signature(copy.stat):
                        raise OSError('duplicate changed after hashing')
                    output.duplicates.append((copy.relative, str(winner.path), str(copy.path)))
                except OSError as exc:
                    output.failures.append(f'SKIP: {copy.path}: {exc}')
    output.conflicts = int(len(output.rows) > 1)
    return output


def _atomic_duplicates(path: Path, duplicates: list[tuple[str, str, str]]) -> None:
    with atomic_text_writer(path, encoding='utf-8-sig', newline='', prefix='.duplicates-') as stream:
        writer = csv.writer(stream)
        writer.writerow(('relative_log_path', 'retained_source', 'duplicate_source'))
        for relative, kept, duplicate in duplicates:
            writer.writerow(tuple(analyze.excel_safe(value) for value in (relative, kept, duplicate)))


@dataclass
class CobExtraction:
    rows: dict[str, dict]
    duplicates: list[tuple[str, str, str]]
    failures: list[str]
    conflicts: int = 0
    missing_timestamps: int = 0


def _discover_hosts(
    groups: list[list[Agent]], now: datetime, only_date: str | None,
    stdout: TextIO, stderr: TextIO, progress: ConsoleProgress | None,
) -> tuple[list[tuple[Agent, dict[str, Path]]], list[str]]:
    """Try one reachable UNC alias per physical host without double-scanning it."""
    discovered: list[tuple[Agent, dict[str, Path]]] = []
    failures: list[str] = []
    for group in groups:
        failed_aliases: list[str] = []
        for agent in group:
            if progress:
                progress.message(f'Discovering host: {agent.host}', error=False)
            try:
                date_folders = _discover_agent_cobs(agent, now, only_date)
            except OSError as exc:
                failed_aliases.append(f'{agent.host}: {exc}')
                continue
            discovered.append((agent, date_folders))
            print(f'HOST: {agent.host}: {len(date_folders)} COB directories', file=stdout)
            break
        else:
            failures.append('WARN: HOST UNAVAILABLE: ' + ' / '.join(failed_aliases))
    for message in failures:
        print(message, file=stderr)
    return discovered, failures


def _collect_cob_logs(
    cob: str, agents: list[tuple[Agent, dict[str, Path]]],
    base: str, exact_folder: str | None,
) -> tuple[dict[tuple[str, str], list[SourceLog]], list[str]]:
    """Discover logical logs across hosts; retain no partial folder listing."""
    logical: dict[tuple[str, str], list[SourceLog]] = defaultdict(list)
    failures: list[str] = []
    for agent, dates in agents:
        parent = dates.get(cob)
        if parent is None:
            continue
        try:
            folders = _scandir_directories(parent)
            matches = ([name for name in folders if name == exact_folder]
                       if exact_folder else [name for name in folders
                       if name == base or name.startswith(f'{base}_{cob}_')])
            for folder_name in matches:
                folder = parent / folder_name
                sources = [
                    SourceLog(cob, folder_name, path.relative_to(folder).as_posix(),
                              agent.host, path, metadata)
                    for path, metadata in analyze.iter_log_files(folder)
                ]
                for source in sources:
                    logical[(source.topology.casefold(), source.relative.casefold())].append(source)
        except OSError as exc:
            failures.append(f'WARN: HOST READ FAILED: {agent.host} / COB {cob}: {exc}')
    return logical, failures


def _enrich_cob_logs(
    logical: dict[tuple[str, str], list[SourceLog]], *,
    encoding: str, now: datetime, recent_minutes: int, workers: int,
    progress: ConsoleProgress | None,
) -> CobExtraction:
    """Process bounded SMB reads; consolidate one result per logical filename."""
    extraction = CobExtraction({}, [], [])
    groups = [logical[key] for key in sorted(logical)]
    if progress:
        progress.set_file_total(len(groups))

    pending: deque[tuple[str, Future[SourceResult]]] = deque()

    def consume() -> None:
        key, task = pending.popleft()
        result = task.result()
        extraction.missing_timestamps += result.missing_timestamps
        extraction.conflicts += result.conflicts
        extraction.failures.extend(result.failures)
        extraction.duplicates.extend(result.duplicates)
        for row in result.rows:
            extraction.rows[row['path'].casefold()] = {'row': row}
        if progress:
            progress.file_completed('enriched' if result.rows else 'skipped', key)

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix='ps-log') as pool:
        for copies in groups:
            key = f'{copies[0].topology}/{copies[0].relative}'
            if progress:
                progress.file_queued(key)
            pending.append((key, pool.submit(_process_group, copies, encoding, now, recent_minutes)))
            if len(pending) >= 2 * workers:
                consume()
        while pending:
            consume()
    return extraction


def _publish_cob_reports(
    *, env_dir: Path, base: str, cob: str, rows: dict[str, dict],
    duplicates: list[tuple[str, str, str]], partial: bool,
    delimiter: str, stdout: TextIO,
) -> int:
    """Keep previously published full reports when source coverage is partial."""
    by_topology: dict[str, dict[str, dict]] = defaultdict(dict)
    for key, record in rows.items():
        folder_name = record['row']['system']
        by_topology[folder_name][key] = record

    for folder_name, output_rows in sorted(by_topology.items()):
        target_dir = env_dir / 'process_scheduler' / base / cob / folder_name
        target = target_dir / ('jobs.partial.csv' if partial else 'jobs.csv')
        analyze.atomic_csv(target, output_rows, delimiter)
        matching_dups = [(relative, winner, duplicate) for relative, winner, duplicate in duplicates
                         if f'/{folder_name.casefold()}/' in winner.replace('\\', '/').casefold()]
        _atomic_duplicates(target_dir / ('duplicates.partial.csv' if partial else 'duplicates.csv'), matching_dups)
        if not partial:
            (target_dir / 'jobs.partial.csv').unlink(missing_ok=True)
            (target_dir / 'duplicates.partial.csv').unlink(missing_ok=True)
        print(f'{"PARTIAL" if partial else "CSV"}: {target} ({len(output_rows)} logs)', file=stdout)
    return len(by_topology)


def extract(
    *, config: dict, config_dir: Path, environment: str, topology: str,
    output_dir: Path, encoding: str, delimiter: str = ',', only_date: str | None = None,
    now: datetime | None = None, stdout: TextIO | None = None,
    stderr: TextIO | None = None, progress: ConsoleProgress | None = None,
) -> int:
    """Return 0 for complete result, 2 for partial, raise for fatal errors.

    A partial run NEVER overwrites a prior complete jobs.csv. It writes
    jobs.partial.csv instead, leaving its incompleteness explicit.
    """
    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    _, groups = settings_for(config, environment, config_dir=config_dir)
    target_root = (output_dir / environment).resolve()
    for agents in groups:
        for agent in agents:
            source_root = agent.root.resolve()
            if target_root.is_relative_to(source_root) or source_root.is_relative_to(target_root):
                raise ValueError('Output directory must be separate from all Process Scheduler log shares')
    base, from_name_date, exact_folder = parse_topology(topology)
    if only_date and not analyze.valid_cob(only_date):
        raise ValueError('--date must be a valid YYYYMMDD date')
    if from_name_date and only_date and from_name_date != only_date:
        raise ValueError('Topology folder date conflicts with --date')
    only_date = from_name_date or only_date
    if len(delimiter) != 1 or delimiter in ('\r', '\n', '"'):
        raise ValueError('Invalid CSV delimiter')
    now = now or datetime.now().astimezone()
    policy = analyze.policy_from_config(config)
    agent_cobs, source_failures = _discover_hosts(
        groups, now, only_date, stdout, stderr, progress,
    )
    if not agent_cobs:
        raise ValueError('No Process Scheduler hosts accessible; no CSV files published')
    eligible = sorted({cob for _, dates in agent_cobs for cob in dates}, reverse=True)
    selected = eligible if only_date else eligible[:policy.cob_scan_limit]
    selected.reverse()
    if not selected:
        raise ValueError('No eligible COB folders found across accessible hosts')
    if progress:
        progress.discovered(len(selected))
    reports = duplicates_total = parsed_total = conflict_total = failed_total = 0
    found_topology = False
    safe_base = base  # Validated as one path component by parse_topology.
    env_dir = output_dir / environment
    with analyze.environment_lock(env_dir):
        for position, cob in enumerate(selected, 1):
            if progress:
                progress.begin_cob(cob, position)
            # Filename collisions with distinct payloads remain separate CSV rows.
            logical, cob_failures = _collect_cob_logs(
                cob, agent_cobs, safe_base, exact_folder,
            )
            if not logical:
                if progress:
                    progress.set_file_total(0)
                    progress.end_cob()
                continue
            found_topology = True
            extraction = _enrich_cob_logs(
                logical, encoding=encoding, now=now,
                recent_minutes=policy.recent_minutes, workers=policy.read_workers,
                progress=progress,
            )
            rows, duplicates = extraction.rows, extraction.duplicates
            conflicts, missing_timestamps = extraction.conflicts, extraction.missing_timestamps
            cob_failures.extend(extraction.failures)
            if conflicts:
                print(f'WARN: COB {cob}: {conflicts} filename collisions have DIFFERENT contents; all retained', file=stderr)
            if missing_timestamps:
                print(f'WARN: COB {cob}: {missing_timestamps} logs have no parseable timestamps', file=stderr)
            for failure in cob_failures:
                print(failure, file=stderr)
            partial = bool(source_failures or cob_failures)
            published = _publish_cob_reports(
                env_dir=env_dir, base=safe_base, cob=cob, rows=rows,
                duplicates=duplicates, partial=partial, delimiter=delimiter,
                stdout=stdout,
            )
            reports += published
            if progress:
                progress.end_cob(written=bool(published))
            parsed_total += len(rows)
            duplicates_total += len(duplicates)
            conflict_total += conflicts
            failed_total += len(cob_failures)
    if not found_topology:
        raise ValueError(f'No .log files found for topology {topology!r} in selected COBs')
    print(f'Process Scheduler: env={environment}; topology={topology}; '
          f'logs={parsed_total}; duplicate copies={duplicates_total}; '
          f'content conflicts={conflict_total}; host errors={len(source_failures)}; '
          f'file/directory errors={failed_total}; reports={reports}', file=stdout)
    return 2 if source_failures or failed_total else 0
