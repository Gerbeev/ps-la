@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if errorlevel 1 (
    set "EXIT_CODE=1"
    goto :finish
)

set "EXIT_CODE=0"
if "%~1"=="" (
    echo Usage: run.cmd PROD [--mode inventory^|enrich^|process-scheduler] [--topology NAME] [--date YYYYMMDD] [--force] [--output-dir PATH] [--no-progress]
    set "EXIT_CODE=2"
    goto :finish
)

python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python 3.11+ is required and the `python` command must be available on PATH. 1>&2
    set "EXIT_CODE=1"
    goto :finish
)

python "%~dp0analyze.py" --env %*
set "EXIT_CODE=%ERRORLEVEL%"

:finish
echo.
echo [log-analyzer] Exit code: %EXIT_CODE%
pause
endlocal & exit /b %EXIT_CODE%
