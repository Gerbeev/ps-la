@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if errorlevel 1 (
    set "EXIT_CODE=1"
    goto :finish
)

set "EXIT_CODE=0"
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python 3.11+ is required and the `python` command must be available on PATH.
    echo Run setup.cmd after adding python.exe to PATH.
    set "EXIT_CODE=1"
    goto :finish
)

python "%~dp0menu.py"
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
    echo.
    echo ERROR: Log Analyzer exited unexpectedly.
)

:finish
echo.
echo [log-analyzer] Exit code: %EXIT_CODE%
pause
endlocal & exit /b %EXIT_CODE%
