"""Local multi-host Process Scheduler smoke and failure-integrity tests."""
from __future__ import annotations

import csv
from datetime import date, datetime, timezone
from io import StringIO
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import analyze
import menu
import process_scheduler as ps


class ProcessSchedulerTests(unittest.TestCase):
    def setUp(self):
        tmp = TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.base = Path(tmp.name)
        self.hosts = [self.base / 'host1', self.base / 'host2']
        self.today = datetime(2026, 10, 8, 12, 0, tzinfo=timezone.utc)
        self.cob = '20261007'
        # Deliberately mismatched day-of-week: must use the actual directory name.
        self.folder = 'DataPlatform_20261007_Thursday'
        self.settings = {
            'encoding': 'utf-8-sig',
            'incremental': {'read_workers': 2, 'cob_scan_limit': 7},
            'environments': {'U5': {'logs_root': 'unused', 'process_scheduler': {
                'share': 'RALogs',
                'topology_url': 'https://example.org/Topology/Index/DataPlatform_20261007_Thursday',
                'default_topology': 'DataPlatform',
                'hosts': [{'name': f'agent{i+1}.example.org', 'root': str(path)}
                          for i, path in enumerate(self.hosts)],
                'host_aliases': {},
            }}},
        }
        self.config = self.base / 'config.json'
        self.save()
        self.output = self.base / 'output'

    def save(self):
        self.config.write_text(json.dumps(self.settings), encoding='utf-8')

    def log(self, host: int, filename: str, text: str, cob: str | None = None,
            folder: str | None = None):
        target = self.hosts[host] / (cob or self.cob) / (folder or self.folder) / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding='utf-8')
        return target

    @staticmethod
    def data(message='Done', *, delay=4):
        return ('2026-10-07 11:01:01,123 [1] INFO : Starting\n'
                f'2026-10-07 11:01:0{delay},123 [1] ERROR : {message}\n')

    def run_extract(self, topology='DataPlatform', date=None):
        out, err = StringIO(), StringIO()
        result = ps.extract(config=analyze.load_config(self.config),
                            config_dir=self.base, environment='U5', topology=topology,
                            output_dir=self.output, encoding='utf-8-sig',
                            only_date=date, now=self.today, stdout=out, stderr=err)
        return result, out.getvalue(), err.getvalue()

    def report(self, partial=False):
        return self.output / 'U5' / 'process_scheduler' / 'DataPlatform' / self.cob / self.folder / (
            'jobs.partial.csv' if partial else 'jobs.csv')

    def rows(self, partial=False):
        with self.report(partial).open(encoding='utf-8-sig', newline='') as stream:
            return list(csv.DictReader(stream))

    def test_duplicate_content_collapses_and_enriches_same_run(self):
        self.log(0, 'job_a.log', self.data())
        self.log(1, 'job_a.log', self.data())
        status, out, _ = self.run_extract()
        self.assertEqual(status, 0)
        self.assertIn('duplicate copies=1', out)
        rows = self.rows()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['job_date'], self.cob)
        self.assertEqual(rows[0]['system'], self.folder)
        self.assertEqual(rows[0]['start_time'], '2026-10-07 11:01:01.123')
        self.assertEqual(rows[0]['duration'], '00:00:03')
        self.assertEqual(rows[0]['error_count'], '1')
        self.assertEqual(rows[0]['enrichment_status'], 'Enriched')
        self.assertIn(str(self.hosts[0]), rows[0]['path'])
        duplicates = self.report().with_name('duplicates.csv').read_text(encoding='utf-8-sig')
        self.assertIn('agent', self.settings['environments']['U5']['process_scheduler']['hosts'][0]['name'])
        self.assertIn('job_a.log', duplicates)

    def test_conflicting_contents_kept_as_separate_rows(self):
        self.log(0, 'job.log', self.data('Oops A'))
        self.log(1, 'job.log', self.data('Oops B'))
        status, out, err = self.run_extract()
        self.assertEqual(status, 0)
        self.assertIn('content conflicts=1', out)
        self.assertIn('DIFFERENT contents', err)
        self.assertEqual(len(self.rows()), 2)
        self.assertEqual(len({row['path'] for row in self.rows()}), 2)

    def test_enabled_hosts_fail_closed_without_overwriting_previous(self):
        self.log(0, 'job.log', self.data())
        self.hosts[1].mkdir()
        self.assertEqual(self.run_extract()[0], 0)
        original = self.report().read_bytes()
        self.settings['environments']['U5']['process_scheduler']['hosts'][1]['root'] = str(self.base / 'offline')
        self.save()
        status, out, err = self.run_extract()
        self.assertEqual(status, 2)
        self.assertIn('HOST UNAVAILABLE', err)
        self.assertIn('PARTIAL', out)
        self.assertTrue(self.report(partial=True).is_file())
        self.assertEqual(self.report().read_bytes(), original)

    def test_full_dated_name_selects_only_exact_folder(self):
        self.log(0, 'job.log', self.data())
        self.log(0, 'skip.log', self.data(), folder='DataPlatform_20261007_Wednesday')
        self.hosts[1].mkdir()
        self.assertEqual(self.run_extract(topology=self.folder)[0], 0)
        self.assertEqual(len(self.rows()), 1)
        self.assertEqual(self.rows()[0]['job_name'], 'job')
        self.assertRaises(ValueError, self.run_extract, self.folder, '20261006')

    def test_generated_default_uses_previous_cob_and_current_weekday(self):
        cases = (
            (date(2026, 10, 8), 'DataPlatform_20261007_Thursday'),
            (date(2026, 10, 9), 'DataPlatform_20261008_Friday'),
            (date(2026, 10, 12), 'DataPlatform_20261011_Monday'),
            (date(2027, 1, 1), 'DataPlatform_20261231_Friday'),
            (date(2028, 3, 1), 'DataPlatform_20280229_Wednesday'),
        )
        for current_day, expected in cases:
            with self.subTest(current_day=current_day):
                self.assertEqual(ps.default_topology_name('DataPlatform', current_day=current_day), expected)
                self.assertEqual(ps.parse_topology(expected)[2], expected)

    def test_generated_default_name_is_an_exact_folder_filter(self):
        self.log(0, 'job.log', self.data())
        self.log(0, 'other.log', self.data(), folder='DataPlatform_20261007_Wednesday')
        self.hosts[1].mkdir()
        selected = ps.default_topology_name('DataPlatform', current_day=self.today.date())
        self.assertEqual(self.run_extract(topology=selected)[0], 0)
        self.assertEqual([row['job_name'] for row in self.rows()], ['job'])

    def test_disabled_host_and_alias_failover(self):
        self.log(1, 'job.log', self.data())
        hosts = self.settings['environments']['U5']['process_scheduler']['hosts']
        self.settings['environments']['U5']['process_scheduler']['host_aliases'] = {
            'agent2.example.org': 'agent1.example.org'
        }
        self.save()
        status, out, err = self.run_extract()
        self.assertEqual(status, 0)
        self.assertEqual(len(self.rows()), 1)
        self.assertNotIn('HOST UNAVAILABLE', err)
        self.assertIn('agent2.example.org', out)

    def test_partial_log_read_preserves_complete_report(self):
        first = self.log(0, 'job.log', self.data())
        self.hosts[1].mkdir()
        self.assertEqual(self.run_extract()[0], 0)
        original = self.report().read_bytes()
        self.log(0, 'new.log', self.data())
        original_open = analyze.open_shared_log
        from contextlib import contextmanager
        @contextmanager
        def failing(path):
            if Path(path).name == 'new.log':
                raise OSError('access denied')
            with original_open(path) as stream:
                yield stream
        with patch.object(analyze, 'open_shared_log', failing):
            status, _, err = self.run_extract()
        self.assertEqual(status, 2)
        self.assertIn('access denied', err)
        self.assertEqual(self.report().read_bytes(), original)
        self.assertEqual(len(self.rows(partial=True)), 1)
        self.assertEqual(first.name, 'job.log')

    def test_reject_path_traversal_and_broken_configuration(self):
        for name in ('../DataPlatform', 'https://example.org', 'Foo/Bar', 'C:\\temp'):
            with self.subTest(name=name):
                self.assertRaises(ValueError, ps.parse_topology, name)
        self.settings['environments']['U5']['process_scheduler']['hosts'][0]['name'] = '../bad'
        self.save()
        self.assertRaises(ValueError, analyze.load_config, self.config)

    def test_menu_3_process_scheduler_integration(self):
        self.log(0, 'job.log', self.data())
        self.hosts[1].mkdir()
        answers = iter(['3', '1', '', 'y', '', '0'])
        buf = StringIO()
        with patch.object(analyze, 'DEFAULT_OUTPUT_DIR', self.output), \
             patch.object(ps, 'date') as system_date, \
             patch.object(ps, 'extract', return_value=0) as extract:
            system_date.today.return_value = date(2026, 10, 8)
            menu_obj = menu.ConsoleMenu(read=lambda _: next(answers), output=buf,
                                        config_path=self.config)
            self.assertEqual(menu_obj.run(), 0)
            self.assertEqual(extract.call_args.kwargs['topology'], self.folder)
            self.assertEqual(extract.call_args.kwargs['environment'], 'U5')
        text = buf.getvalue()
        self.assertIn('3. Extract Process Scheduler Logs', text)
        self.assertIn('COB date    : 20261007 (from topology name)', text)
        self.assertIn('Process Scheduler extraction completed successfully', text)

    def test_cli_process_scheduler_uses_generated_default_name(self):
        self.log(0, 'job.log', self.data())
        self.hosts[1].mkdir()
        with patch.object(ps, 'date') as system_date:
            system_date.today.return_value = date(2026, 10, 8)
            result = analyze.main([
                '--config', str(self.config), '--env', 'U5', '--mode', 'process-scheduler',
                '--output-dir', str(self.output), '--no-progress',
            ])
        self.assertEqual(result, 0)
        self.assertEqual(len(self.rows()), 1)

    def test_cli_historical_date_derives_next_day_suffix(self):
        self.log(0, 'job.log', self.data())
        self.hosts[1].mkdir()
        with patch.object(ps, 'extract', return_value=0) as extract:
            result = analyze.main([
                '--config', str(self.config), '--env', 'U5', '--mode', 'process-scheduler',
                '--date', '20261007', '--no-progress',
            ])
        self.assertEqual(result, 0)
        self.assertEqual(extract.call_args.kwargs['topology'], self.folder)
        self.assertEqual(extract.call_args.kwargs['only_date'], self.cob)


if __name__ == '__main__':
    unittest.main()
