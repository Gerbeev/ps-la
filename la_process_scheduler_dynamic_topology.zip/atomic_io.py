"""Durable, replace-on-success writes for local reports and configuration."""

from __future__ import annotations

from contextlib import contextmanager
import os
from pathlib import Path
import tempfile
from typing import Iterator, TextIO


@contextmanager
def atomic_text_writer(
    target: Path, *, encoding: str, newline: str,
    prefix: str,
) -> Iterator[TextIO]:
    """Write to a same-directory temporary file and publish only after fsync.

    A failed serializer, interrupted write, or failed replacement leaves the
    previously published target untouched and removes the temporary file.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding=encoding, newline=newline,
            dir=target.parent, prefix=prefix, suffix=".tmp", delete=False,
        ) as stream:
            temporary = Path(stream.name)
            yield stream
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
