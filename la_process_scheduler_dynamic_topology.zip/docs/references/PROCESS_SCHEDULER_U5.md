# U5 Process Scheduler — endpoint and filesystem references

Reference for the configured U5 topology, agents, and log-storage paths. This is **not** an API/DOM contract.

## Scheduler topology / Agents

- Page reference: `https://npb14716831u5p1.ubscloud-prod.msad.ubs.net/Topology/Index/DataPlatform_20260924_Friday`
- Topology example on the web UI: `DataPlatform_20260924_Friday`.
- Visible U5 agents: `ra-u5-as-06.ubs.net`, `ra-u5-as-05.ubs.net`, `ra-u5-dp-01.ubs.net`, `ra-u5-as-03.ubs.net`, `ra-u5-as-08.ubs.net`, `ra-u5-rs-01.ubs.net` (previously reported Inactive), `ra-u5-as-11.ubs.net`, `ra-u5-ts-02.ubs.net`, `ra-u5-as-04.ubs.net`, `ra-u5-as-07.ubs.net`, `ra-u5-as-01.ubs.net`, `ra-u5-ts-01.ubs.net`, `ra-u5-dp-02.ubs.net`, `ra-u5-as-10.ubs.net`.
- Host aliases were mentioned by the user, but **no canonical alias equivalences are configured**. `host_aliases` therefore starts empty.

## Network logs

- Browser index example: `http://ra-u5-as-08.ubs.net/RALogs/20261007/DataPlatform_20261007_Thursday/`
- File UNC path example: `\\ra-u5-as-08.ubs.net\RALogs\20261007\DataPlatform_20261007_Thursday\IB_CT_CVA_1109_U5_Database_Sessions_RRS.log`
- Date folder: `20261007`; topology folder: `DataPlatform_20261007_Thursday`.
- **Do not infer the weekday**: the example folder's `Thursday` suffix does not match the calendar weekday for `2026-10-07`.
- Directory index columns: `Name`, `Size`, `Date Modified`.
- Some log entries are 0 bytes; do not silently skip empty logs.

## Boundaries

The Agents page is part of an internal authenticated Process Scheduler web UI. No validated HTML/JSON endpoint or dynamic update contract is configured. The extractor therefore uses a configured agent host inventory (from the configured inventory) and reads the **UNC shares directly using current Windows permissions**. It does not assume an unverified Agents API. When the host inventory changes, update `config.json`.
